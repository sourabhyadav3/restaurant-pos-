import React, { useState, useMemo } from 'react';
import { 
  Plus, 
  Search, 
  MoreVertical, 
  Mail, 
  Phone, 
  Calendar,
  BadgeCheck,
  UserCheck,
  Filter,
  Shield,
  Clock,
  ChevronRight,
  Star,
  MapPin,
  Sparkles,
  X,
  Edit2,
  Trash2,
  AlertCircle,
  CheckCircle2
} from 'lucide-react';
import { cn } from '../utils/cn';

const Staff = () => {
  const [activeTab, setActiveTab] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedStaff, setSelectedStaff] = useState(null);
  const [editingStaff, setEditingStaff] = useState(null);
  const [deleteConfirm, setDeleteConfirm] = useState(null);
  const [toast, setToast] = useState(null);

  const [staffMembers, setStaffMembers] = useState([
    { id: 1, name: 'Rahul Sharma', role: 'Waiter', shift: 'Morning', status: 'Active', email: 'rahul@example.com', phone: '+91 9876543210', joined: 'Mar 2024', rating: '4.8', avatar: 'RS' },
    { id: 2, name: 'Priya Singh', role: 'Chef', shift: 'Evening', status: 'Active', email: 'priya@example.com', phone: '+91 9876543211', joined: 'Jan 2024', rating: '4.9', avatar: 'PS' },
    { id: 3, name: 'Amit Kumar', role: 'Cashier', shift: 'Morning', status: 'Inactive', email: 'amit@example.com', phone: '+91 9876543212', joined: 'Feb 2024', rating: '4.5', avatar: 'AK' },
    { id: 4, name: 'Sneha Patel', role: 'Manager', shift: 'General', status: 'Active', email: 'sneha@example.com', phone: '+91 9876543213', joined: 'Oct 2023', rating: '5.0', avatar: 'SP' },
    { id: 5, name: 'Vikram Das', role: 'Waiter', shift: 'Evening', status: 'Active', email: 'vikram@example.com', phone: '+91 9876543214', joined: 'Apr 2024', rating: '4.7', avatar: 'VD' },
    { id: 6, name: 'Anjali Gupta', role: 'Chef', shift: 'Morning', status: 'Active', email: 'anjali@example.com', phone: '+91 9876543215', joined: 'May 2024', rating: '4.6', avatar: 'AG' },
  ]);

  const roles = ['All', 'Admin', 'Manager', 'Chef', 'Waiter', 'Cashier'];

  const showToast = (message, type = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  const handleSaveMember = (data) => {
    if (editingStaff) {
      setStaffMembers(prev => prev.map(m => m.id === editingStaff.id ? { ...m, ...data } : m));
      showToast('Staff profile updated');
    } else {
      const newMember = {
        ...data,
        id: Date.now(),
        rating: '5.0',
        joined: 'Just Now',
        avatar: data.name.split(' ').map(n => n[0]).join('').toUpperCase()
      };
      setStaffMembers(prev => [newMember, ...prev]);
      showToast('New staff member added');
    }
    setShowAddModal(false);
    setEditingStaff(null);
  };

  const handleDelete = (id) => {
    setStaffMembers(prev => prev.filter(m => m.id !== id));
    setDeleteConfirm(null);
    showToast('Staff member removed', 'error');
  };

  const toggleStatus = (id) => {
    setStaffMembers(prev => prev.map(m => {
      if (m.id !== id) return m;
      return { ...m, status: m.status === 'Active' ? 'Inactive' : 'Active' };
    }));
    showToast('Status updated');
  };

  const filteredStaff = useMemo(() => {
    return staffMembers.filter(m => {
      const matchesTab = activeTab === 'All' || m.role === activeTab;
      const query = searchQuery.toLowerCase();
      const matchesSearch = m.name.toLowerCase().includes(query) || 
                           m.email.toLowerCase().includes(query) || 
                           m.role.toLowerCase().includes(query);
      return matchesTab && matchesSearch;
    });
  }, [staffMembers, activeTab, searchQuery]);

  return (
    <div className="space-y-5 h-full flex flex-col overflow-hidden relative">
      {/* Toast Notification */}
      {toast && (
        <div 
          className={cn(
            "fixed top-4 left-1/2 -translate-x-1/2 z-[300] px-6 py-3 rounded-2xl shadow-2xl flex items-center gap-3 font-black text-[10px] uppercase tracking-widest border",
            toast.type === 'success' ? "bg-primary border-primary/20 text-white" : "bg-rose-600 border-rose-500 text-white"
          )}
        >
          {toast.type === 'success' ? <CheckCircle2 className="w-4 h-4 text-white" /> : <AlertCircle className="w-4 h-4" />}
          {toast.message}
        </div>
      )}

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 shrink-0">
        <div>
          <h2 className="text-xl lg:text-2xl font-black text-text-primary uppercase tracking-tight leading-none">Staff Directory</h2>
          <p className="text-text-secondary mt-1 text-xs lg:text-sm font-medium">Manage your restaurant team.</p>
        </div>
        <div className="flex items-center gap-3 w-full sm:w-auto">
           <div className="relative flex-1 group sm:hidden">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300 group-focus-within:text-primary" />
              <input 
                type="text" 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search..." 
                className="w-full pl-9 pr-3 py-2.5 bg-white border border-slate-100 rounded-xl focus:ring-4 focus:ring-primary/10 focus:border-primary outline-none shadow-sm text-[10px] font-bold uppercase tracking-widest"
              />
           </div>
           <div className="relative group hidden sm:block">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300 group-focus-within:text-primary" />
              <input 
                type="text" 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search staff..." 
                className="pl-11 pr-4 py-2.5 bg-white border border-slate-100 rounded-xl focus:ring-4 focus:ring-primary/10 focus:border-primary outline-none shadow-sm text-xs font-bold uppercase tracking-widest"
              />
           </div>
           <button 
             onClick={() => { setEditingStaff(null); setShowAddModal(true); }}
             className="btn-primary flex items-center justify-center gap-2 py-3 lg:py-2 px-5 shadow-xl shadow-primary/20 text-[10px] lg:text-xs font-black uppercase tracking-widest shrink-0"
           >
             <Plus className="w-4 h-4 stroke-[3]" /> <span className="hidden sm:inline">Add Member</span><span className="sm:hidden">Add</span>
           </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide shrink-0 -mx-1 px-1">
        {roles.map(role => (
          <button
            key={role}
            onClick={() => setActiveTab(role)}
            className={cn(
              "px-4 py-2 rounded-lg lg:rounded-xl text-[9px] lg:text-[10px] font-bold uppercase tracking-wider border-2 whitespace-nowrap transition-all",
              activeTab === role 
                ? "bg-primary text-white border-primary shadow-lg shadow-primary/20" 
                : "bg-white text-text-secondary border-transparent hover:border-primary/20 hover:bg-indigo-50/30"
            )}
          >
            {role}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto pb-20 lg:pb-8 pr-1 lg:pr-2 scrollbar-hide">
        {filteredStaff.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 gap-4 lg:gap-6">
            {filteredStaff.map((member) => (
              <div 
                key={member.id} 
                className={cn(
                  "card group border border-slate-100 relative overflow-hidden p-5 lg:p-6 rounded-[2rem] lg:rounded-[2.5rem] bg-white cursor-pointer active:scale-[0.98] transition-all",
                  member.status === 'Inactive' && "opacity-60 grayscale-[0.5]"
                )}
                onClick={() => setSelectedStaff(member)}
              >
                {/* Status Badge */}
                <div className="absolute top-5 lg:top-6 right-5 lg:right-6 flex items-center gap-2">
                  <button 
                    onClick={(e) => { e.stopPropagation(); setEditingStaff(member); setShowAddModal(true); }}
                    className="p-2 bg-slate-50 text-slate-400 hover:text-primary hover:bg-white rounded-lg shadow-sm border border-transparent hover:border-slate-100 hidden sm:block opacity-0 group-hover:opacity-100"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button 
                    onClick={(e) => { e.stopPropagation(); toggleStatus(member.id); }}
                    className={cn(
                      "px-2 py-0.5 rounded-lg text-[7px] lg:text-[8px] font-black uppercase tracking-widest border shadow-sm",
                      member.status === 'Active' ? "bg-green-50 text-success border-green-100" : "bg-red-50 text-danger border-red-100"
                    )}
                  >
                    {member.status}
                  </button>
                </div>

                <div className="flex items-center gap-4 mb-6">
                  <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center text-primary font-black text-xl border-4 border-white shadow-xl">
                    {member.avatar}
                  </div>
                  <div>
                    <h3 className="text-lg font-black text-text-primary leading-none group-hover:text-primary">{member.name}</h3>
                    <div className="flex items-center gap-2 mt-2">
                       <span className="flex items-center gap-1.5 text-[9px] font-bold text-text-secondary uppercase tracking-widest">
                          <Shield className="w-3 h-3 text-primary" /> {member.role}
                       </span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 py-5 border-y border-slate-100 border-dashed">
                   <div className="space-y-1.5">
                      <p className="text-[8px] font-black text-slate-400 uppercase tracking-[0.2em]">Current Shift</p>
                      <p className="text-xs font-black text-text-primary flex items-center gap-2">
                         <Clock className="w-4 h-4 text-primary" /> {member.shift}
                      </p>
                   </div>
                   <div className="space-y-1.5">
                      <p className="text-[8px] font-black text-slate-400 uppercase tracking-[0.2em]">Efficiency</p>
                      <p className="text-xs font-black text-text-primary flex items-center gap-2 text-yellow-600">
                         <Star className="w-4 h-4 fill-yellow-500 text-yellow-500" /> {member.rating}
                      </p>
                   </div>
                </div>

                <div className="mt-6 space-y-3">
                  <div className="flex items-center gap-3 text-xs font-bold text-text-secondary bg-slate-50/50 p-3 rounded-2xl border border-transparent group-hover:border-primary/10">
                    <div className="p-2 bg-white rounded-xl shadow-sm">
                       <Mail className="w-3.5 h-3.5 text-primary" />
                    </div>
                    <span className="truncate text-[11px]">{member.email}</span>
                  </div>
                </div>

                <div className="mt-6 pt-5 border-t border-slate-100 flex items-center justify-between">
                   <p className="text-[9px] font-black text-slate-300 uppercase tracking-widest">Joined {member.joined}</p>
                   <button 
                     onClick={() => setSelectedStaff(member)}
                     className="flex items-center gap-1.5 text-[10px] font-black text-primary uppercase tracking-[0.2em]"
                   >
                      Details <ChevronRight className="w-4 h-4" />
                   </button>
                </div>

                {/* Visual Accent */}
                <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-primary/5 rounded-full blur-3xl" />
              </div>
            ))}
          </div>
        ) : (
          <div className="py-20 flex flex-col items-center justify-center text-center">
            <div className="w-20 h-20 bg-slate-50 rounded-[2.5rem] flex items-center justify-center mb-6">
              <Search className="w-8 h-8 text-slate-200" />
            </div>
            <h3 className="text-xl font-black uppercase tracking-tight text-text-primary">No staff members found</h3>
            <p className="text-text-secondary text-[10px] font-black uppercase tracking-widest mt-2 max-w-xs leading-relaxed">
              We couldn't find any team members matching your current filters or search query.
            </p>
            <button 
              onClick={() => { setActiveTab('All'); setSearchQuery(''); }}
              className="mt-8 text-primary font-black uppercase tracking-[0.25em] text-[8px] hover:underline"
            >
              Reset All Filters
            </button>
          </div>
        )}
      </div>

      {/* Add / Edit Staff Modal */}
      {showAddModal && (
        <StaffModal 
          staff={editingStaff} 
          onClose={() => { setShowAddModal(false); setEditingStaff(null); }}
          onSave={handleSaveMember}
        />
      )}

      {/* Delete Confirmation */}
       {deleteConfirm && (
        <div className="fixed inset-0 z-[250] flex items-center justify-center p-4 lg:p-6">
           <div onClick={() => setDeleteConfirm(null)} className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" />
           <div 
             className="relative w-full max-w-sm bg-white rounded-t-[2.5rem] lg:rounded-[2.5rem] p-6 lg:p-8 shadow-2xl overflow-hidden self-end lg:self-center"
           >
             <div className="w-14 h-14 lg:w-16 lg:h-16 bg-rose-50 text-rose-500 rounded-2xl flex items-center justify-center mx-auto mb-6">
               <AlertCircle className="w-7 h-7 lg:w-8 lg:h-8" />
             </div>
             <h3 className="text-lg lg:text-xl font-black text-center uppercase tracking-tight">Confirm Removal</h3>
             <p className="text-xs lg:text-sm text-center text-slate-400 mt-2 font-medium leading-relaxed">
               Remove <span className="text-slate-900 font-bold">{deleteConfirm.name}</span>? This action is permanent.
             </p>
             <div className="mt-8 flex gap-3">
               <button onClick={() => setDeleteConfirm(null)} className="flex-1 py-3.5 lg:py-4 border-2 border-slate-100 rounded-xl lg:rounded-2xl font-black uppercase tracking-widest text-[9px] hover:bg-slate-50">Cancel</button>
               <button onClick={() => handleDelete(deleteConfirm.id)} className="flex-1 py-3.5 lg:py-4 bg-rose-600 text-white rounded-xl lg:rounded-2xl font-black uppercase tracking-widest text-[9px] shadow-xl shadow-rose-200">Delete</button>
             </div>
           </div>
        </div>
      )}

      {/* Staff Detail Side Drawer */}
      {selectedStaff && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 sm:p-6">
          <div onClick={() => setSelectedStaff(null)} className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" />
          <div 
            className="relative w-full sm:max-w-[520px] max-h-[90vh] sm:max-h-[85vh] bg-white shadow-2xl z-[201] flex flex-col rounded-t-[2.5rem] sm:rounded-[2.5rem] overflow-hidden self-end sm:self-center"
          >
            <div className="px-5 py-4 lg:px-6 lg:py-5 border-b border-slate-50 bg-slate-50/30 flex justify-between items-center shrink-0">
               <div className="flex items-center gap-3 lg:gap-4">
                  <div className="w-12 h-12 lg:w-14 lg:h-14 bg-primary text-white rounded-xl lg:rounded-2xl flex items-center justify-center font-black text-xl lg:text-2xl shadow-xl shrink-0">{selectedStaff.avatar}</div>
                  <div>
                     <h3 className="text-lg lg:text-xl font-black tracking-tight uppercase leading-none">{selectedStaff.name}</h3>
                     <p className="text-[9px] lg:text-[10px] font-black text-primary uppercase tracking-widest mt-1.5 lg:mt-2 flex items-center gap-1.5 leading-none">
                       <BadgeCheck className="w-3 h-3" /> Record • ID-{selectedStaff.id}
                     </p>
                  </div>
               </div>
               <button onClick={() => setSelectedStaff(null)} className="p-2 lg:p-3 hover:bg-white rounded-xl lg:rounded-2xl transition-all shadow-sm border border-transparent hover:border-slate-100"><X className="w-5 lg:w-5 h-5 lg:h-5 text-slate-400" /></button>
            </div>

            <div className="flex-1 overflow-y-auto px-5 py-6 lg:px-6 lg:py-8 space-y-6 lg:space-y-10 scrollbar-hide">
               <div className="grid grid-cols-2 gap-3 lg:gap-4">
                  <div className="p-4 lg:p-5 bg-slate-50 rounded-xl lg:rounded-2xl border border-slate-100 text-center">
                     <p className="text-[8px] lg:text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1.5 lg:mb-2">Role Type</p>
                     <p className="font-black text-xs lg:text-sm text-text-primary uppercase tracking-tight flex items-center justify-center gap-1.5 lg:gap-2">
                       <Shield className="w-3 h-3 lg:w-3.5 lg:h-3.5 text-primary" /> {selectedStaff.role}
                     </p>
                  </div>
                  <div className="p-4 lg:p-5 bg-slate-50 rounded-xl lg:rounded-2xl border border-slate-100 text-center">
                     <p className="text-[8px] lg:text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1.5 lg:mb-2">Status</p>
                     <span className={cn(
                       "badge border-none font-black text-[8px] lg:text-[9px] uppercase px-3 lg:px-4 py-1 lg:py-1.5 rounded-lg shadow-sm",
                       selectedStaff.status === 'Active' ? "bg-emerald-50 text-emerald-600" : "bg-rose-50 text-rose-600"
                     )}>{selectedStaff.status}</span>
                  </div>
               </div>

               <div className="space-y-4">
                  <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] ml-2">Communication Hub</h4>
                  <div className="space-y-3">
                     <div className="flex items-center justify-between p-5 bg-white border-2 border-slate-50 rounded-3xl hover:border-primary/20 group cursor-pointer shadow-sm hover:shadow-md">
                        <div className="flex items-center gap-4">
                           <div className="w-12 h-12 bg-indigo-50 rounded-2xl flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white shadow-sm"><Phone className="w-5 h-5" /></div>
                           <div className="flex flex-col">
                             <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-0.5">Mobile Line</span>
                             <span className="font-black text-sm text-text-primary tracking-tight">{selectedStaff.phone}</span>
                           </div>
                        </div>
                        <ChevronRight className="w-4 h-4 text-slate-200 group-hover:text-primary transition-all" />
                     </div>
                     <div className="flex items-center justify-between p-5 bg-white border-2 border-slate-50 rounded-3xl hover:border-primary/20 group cursor-pointer shadow-sm hover:shadow-md">
                        <div className="flex items-center gap-4">
                           <div className="w-12 h-12 bg-emerald-50 rounded-2xl flex items-center justify-center text-emerald-600 group-hover:bg-emerald-600 group-hover:text-white shadow-sm"><Mail className="w-5 h-5" /></div>
                           <div className="flex flex-col">
                             <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-0.5">Corporate Mail</span>
                             <span className="font-black text-sm text-text-primary tracking-tight truncate max-w-[200px]">{selectedStaff.email}</span>
                           </div>
                        </div>
                        <ChevronRight className="w-4 h-4 text-slate-200 group-hover:text-primary transition-all" />
                     </div>
                  </div>
               </div>

               <div className="p-5 lg:p-6 bg-primary rounded-[2rem] lg:rounded-[3rem] text-white shadow-2xl relative overflow-hidden group">
                  <div className="relative z-10 space-y-6 lg:space-y-8">
                     <div className="flex justify-between items-center border-b border-white/10 pb-4 lg:pb-6">
                        <div>
                          <p className="text-[8px] lg:text-[10px] font-black text-white/40 uppercase tracking-[0.2em] mb-1">Intelligence</p>
                          <h4 className="text-xl lg:text-3xl font-black text-white uppercase tracking-tighter">Alpha Score</h4>
                        </div>
                        <div className="flex flex-col items-end gap-0.5 lg:gap-1">
                           <div className="flex items-center gap-1 lg:gap-1.5">
                             <Star className="w-4 h-4 lg:w-6 lg:h-6 fill-white text-white" />
                             <span className="text-2xl lg:text-4xl font-black text-white tracking-tighter">{selectedStaff.rating}</span>
                           </div>
                           <p className="text-[7px] lg:text-[8px] font-black text-white/40 uppercase tracking-widest">Percentile</p>
                        </div>
                     </div>
                     <div className="grid grid-cols-2 gap-4 lg:gap-8 pt-1 lg:pt-2">
                        <div className="space-y-0.5 lg:space-y-1">
                           <p className="text-[7px] lg:text-[8px] font-black text-white/40 uppercase tracking-widest mb-1 lg:mb-1.5">Success Ratio</p>
                           <div className="flex items-baseline gap-1 lg:gap-2">
                             <p className="text-lg lg:text-xl font-black uppercase tracking-tighter">98.2<span className="text-[9px] lg:text-[10px] ml-0.5 text-white/40">%</span></p>
                           </div>
                        </div>
                        <div className="space-y-0.5 lg:space-y-1">
                           <p className="text-[7px] lg:text-[8px] font-black text-white/40 uppercase tracking-widest mb-1 lg:mb-1.5">Workload</p>
                           <div className="flex items-baseline gap-1 lg:gap-2">
                             <p className="text-lg lg:text-xl font-black uppercase tracking-tighter">1,240<span className="text-[9px] lg:text-[10px] ml-0.5 text-white/40">pts</span></p>
                           </div>
                        </div>
                     </div>
                  </div>
                  <Sparkles className="absolute -bottom-8 lg:-bottom-10 -right-8 lg:-right-10 w-32 lg:w-44 h-32 lg:h-44 text-white opacity-5" />
               </div>
            </div>

            <div className="px-5 py-5 lg:px-6 lg:py-6 border-t border-slate-50 flex gap-3 lg:gap-4 bg-white shrink-0">
               <button 
                onClick={() => { setSelectedStaff(null); setDeleteConfirm(selectedStaff); }}
                className="flex-1 py-3.5 lg:py-4.5 border-2 border-slate-100 rounded-xl lg:rounded-2xl font-black text-[9px] lg:text-[10px] uppercase tracking-[0.2em] hover:bg-rose-50 hover:border-rose-100 hover:text-rose-500 transition-all shrink-0"
               >
                 Deactivate
               </button>
               <button 
                onClick={() => { setEditingStaff(selectedStaff); setShowAddModal(true); setSelectedStaff(null); }}
                className="flex-1 btn-primary py-3.5 lg:py-4.5 rounded-xl lg:rounded-2xl font-black text-[9px] lg:text-[10px] uppercase tracking-[0.2em] shadow-xl shadow-primary/20"
               >
                 Update Records
               </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const StaffModal = ({ staff, onClose, onSave }) => {
  const [formData, setFormData] = useState(staff || { 
    name: '', 
    email: '', 
    phone: '', 
    role: 'Waiter', 
    shift: 'Morning', 
    status: 'Active' 
  });
  const [errors, setErrors] = useState({});

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Full name required';
    if (!formData.email.trim() || !formData.email.includes('@')) newErrors.email = 'Valid email required';
    if (!formData.role) newErrors.role = 'Role is required';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validate()) {
      onSave(formData);
    }
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 lg:p-6">
      <div onClick={onClose} className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" />
      <div 
        className="relative w-full max-w-xl bg-white rounded-t-[2.5rem] lg:rounded-[2.5rem] shadow-2xl overflow-hidden border border-white/20 self-end lg:self-center"
      >
        <div className="px-6 py-6 lg:px-10 lg:py-8 border-b border-slate-50 flex justify-between items-center bg-slate-50/20 shrink-0">
          <div>
            <h3 className="text-xl lg:text-2xl font-black uppercase tracking-tight leading-none">{staff ? 'Edit Personnel' : 'Onboard Talent'}</h3>
            <p className="text-[8px] lg:text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1.5 lg:mt-1.5 leading-none">{staff ? 'Update records' : 'Register professional'}</p>
          </div>
          <button onClick={onClose} className="p-2 lg:p-3 hover:bg-white rounded-xl lg:rounded-2xl transition-all shadow-sm border border-transparent hover:border-slate-100"><X className="w-5 lg:w-6 h-5 lg:h-6 text-slate-400" /></button>
        </div>

        <form onSubmit={handleSubmit} className="px-6 py-8 lg:p-10 space-y-6 lg:space-y-8 max-h-[70vh] overflow-y-auto scrollbar-hide">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 lg:gap-8">
             <div className="space-y-1.5">
                <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Full Identity</label>
                <input 
                  type="text" 
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  placeholder="e.g. John Wick" 
                  className={cn(
                    "w-full px-5 lg:px-6 py-3.5 lg:py-4 bg-slate-50 border rounded-xl lg:rounded-2xl focus:ring-4 focus:ring-primary/10 focus:border-primary outline-none font-bold text-xs lg:text-sm",
                    errors.name ? "border-rose-200 bg-rose-50/10" : "border-slate-100"
                  )}
                />
                {errors.name && <p className="text-[9px] font-bold text-rose-500 ml-1 mt-1">{errors.name}</p>}
             </div>
             <div className="space-y-1.5">
                <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Role Type</label>
                <select 
                  value={formData.role}
                  onChange={(e) => setFormData({...formData, role: e.target.value})}
                  className="w-full px-5 lg:px-6 py-3.5 lg:py-4 bg-slate-50 border border-slate-100 rounded-xl lg:rounded-2xl focus:ring-4 focus:ring-primary/10 focus:border-primary outline-none font-bold text-xs lg:text-sm appearance-none"
                >
                   <option>Admin</option>
                   <option>Manager</option>
                   <option>Chef</option>
                   <option>Waiter</option>
                   <option>Cashier</option>
                </select>
             </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 lg:gap-8">
            <div className="space-y-1.5">
               <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Email Terminal</label>
               <input 
                 type="email" 
                 value={formData.email}
                 onChange={(e) => setFormData({...formData, email: e.target.value})}
                 placeholder="john@restaurant.com" 
                 className={cn(
                  "w-full px-5 lg:px-6 py-3.5 lg:py-4 bg-slate-50 border rounded-xl lg:rounded-2xl focus:ring-4 focus:ring-primary/10 focus:border-primary outline-none font-bold text-xs lg:text-sm",
                  errors.email ? "border-rose-200 bg-rose-50/10" : "border-slate-100"
                )}
               />
               {errors.email && <p className="text-[9px] font-bold text-rose-500 ml-1 mt-1">{errors.email}</p>}
            </div>
            <div className="space-y-1.5">
               <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Mobile Line</label>
               <input 
                 type="tel" 
                 value={formData.phone}
                 onChange={(e) => setFormData({...formData, phone: e.target.value})}
                 placeholder="+91 00000 00000" 
                 className="w-full px-5 lg:px-6 py-3.5 lg:py-4 bg-slate-50 border border-slate-100 rounded-xl lg:rounded-2xl focus:ring-4 focus:ring-primary/10 focus:border-primary outline-none font-bold text-xs lg:text-sm" 
               />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-8 items-end">
             <div className="space-y-2">
                <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Duty Shift</label>
                <div className="flex gap-2">
                   {['Morning', 'Evening', 'General'].map(s => (
                     <button 
                       key={s} 
                       type="button"
                       onClick={() => setFormData({...formData, shift: s})}
                       className={cn(
                         "flex-1 py-3 rounded-xl border-2 text-[9px] font-black uppercase tracking-widest",
                         formData.shift === s ? "bg-primary border-primary text-white shadow-lg shadow-primary/20" : "bg-white border-slate-100 text-slate-400 hover:border-primary/20"
                       )}
                     >
                       {s}
                     </button>
                   ))}
                </div>
             </div>
             <div className="flex gap-4">
                <button type="button" onClick={onClose} className="flex-1 py-4 border-2 border-slate-100 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-slate-50">Cancel</button>
                <button type="submit" className="flex-1 btn-primary py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl shadow-primary/20">
                  {staff ? 'Update Profile' : 'Confirm Onboard'}
                </button>
             </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Staff;
