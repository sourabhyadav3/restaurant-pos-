import React, { useState } from 'react';
import { 
  History, 
  ChevronRight, 
  Clock, 
  CheckCircle2, 
  UtensilsCrossed, 
  ChevronLeft,
  Search,
  RotateCcw,
  Star,
  MapPin
} from 'lucide-react';
import { cn } from '../utils/cn';
import { useOrders } from '../context/OrdersContext';
import { useCustomer } from '../context/CustomerContext';
import { useNavigate } from 'react-router-dom';

const CustomerOrders = () => {
  const navigate = useNavigate();
  const { orders, cancelOrder } = useOrders();
  const { profile, addToCart } = useCustomer();
  const [activeTab, setActiveTab] = useState('Active');

  // Filter orders for the current customer/table
  const customerOrders = orders.filter(o => 
    (o.customer === profile.name || o.table === `T-${profile.tableId}`)
  );

  const filteredOrders = customerOrders.filter(order => {
    const isActive = ['Pending', 'New', 'Cooking', 'Ready'].includes(order.status);
    return activeTab === 'Active' ? isActive : !isActive;
  });

  const getStatusColor = (status) => {
    switch(status) {
      case 'New': return 'text-blue-500 bg-blue-50 border-blue-100';
      case 'Pending': return 'text-orange-500 bg-orange-50 border-orange-100';
      case 'Cooking': return 'text-indigo-500 bg-indigo-50 border-indigo-100';
      case 'Ready': return 'text-emerald-500 bg-emerald-50 border-emerald-100';
      case 'Delivered': return 'text-slate-500 bg-slate-50 border-slate-100';
      case 'Cancelled': return 'text-rose-500 bg-rose-50 border-rose-100';
      default: return 'text-slate-500 bg-slate-50 border-slate-100';
    }
  };

  const handleReorder = (order) => {
    // This is simplified reorder logic
    alert('Adding items from ' + order.id + ' to cart!');
    navigate('/customer/order');
  };

  return (
    <div className="flex flex-col h-full gap-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 px-1">
         <div className="flex items-center gap-3">
            <button onClick={() => navigate(-1)} className="p-2.5 bg-white rounded-xl shadow-sm border border-slate-100 lg:hidden">
               <ChevronLeft className="w-5 h-5 text-text-primary" />
            </button>
            <h2 className="text-xl lg:text-2xl font-black text-text-primary uppercase tracking-tight">Order Management</h2>
         </div>
         <div className="flex bg-white p-1.5 rounded-2xl shadow-sm border border-slate-100 w-fit self-start lg:self-center">
            {['Active', 'History'].map(tab => (
              <button 
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={cn(
                  "px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all",
                  activeTab === tab ? "bg-primary text-white shadow-lg" : "text-slate-400 hover:text-primary"
                )}
              >
                {tab}
              </button>
            ))}
         </div>
      </div>

      {/* Orders List */}
      <div className="flex-1 overflow-y-auto pr-2 scrollbar-hide space-y-4 pb-20 lg:pb-10">
        {filteredOrders.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-[50vh] text-center opacity-50">
             <History className="w-16 h-16 text-slate-200 mb-4" />
             <p className="text-sm font-black uppercase tracking-widest text-slate-400">No {activeTab.toLowerCase()} orders found</p>
          </div>
        ) : (
          filteredOrders.map((order) => (
            <div key={order.id} className="card p-5 lg:p-6 bg-white border-none shadow-xl shadow-slate-100/50 hover:bg-slate-50 transition-all group">
               <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                  <div className="flex items-start gap-4 lg:gap-6">
                      <div className="w-14 h-14 lg:w-16 lg:h-16 bg-slate-50 rounded-2xl flex items-center justify-center text-3xl shadow-inner group-hover:scale-105 transition-transform">
                        {['Cooking', 'Ready'].includes(order.status) ? '🍳' : order.status === 'Delivered' ? '✅' : order.status === 'Cancelled' ? '❌' : '⏳'}
                      </div>
                      <div className="space-y-1">
                         <div className="flex items-center gap-2">
                            <span className={cn("px-2.5 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest border", getStatusColor(order.status))}>
                               {order.status}
                            </span>
                            <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest">• {order.id}</span>
                         </div>
                         <h4 className="text-base lg:text-lg font-black text-text-primary uppercase tracking-tight leading-tight pt-1">
                            {order.itemsList ? order.itemsList.map(i => i.name).join(', ') : 'Custom Order'}
                         </h4>
                         <div className="flex items-center gap-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest pt-1">
                            <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {order.time || 'Recent'}</span>
                            <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> {order.table}</span>
                         </div>
                      </div>
                  </div>

                  <div className="flex flex-row md:flex-col items-center md:items-end justify-between md:justify-center gap-2 border-t md:border-t-0 pt-4 md:pt-0 border-slate-50">
                     <div className="text-right">
                        <p className="text-[9px] font-black text-slate-300 uppercase tracking-widest mb-0.5">Order Total</p>
                        <p className="text-lg lg:text-xl font-black text-text-primary tracking-tighter">₹{order.total}</p>
                     </div>
                     <div className="flex items-center gap-2">
                        {activeTab === 'History' ? (
                          <button 
                            onClick={() => handleReorder(order)}
                            className="flex items-center gap-2 px-4 py-2.5 bg-white border border-slate-100 rounded-xl text-[9px] font-black uppercase tracking-widest hover:bg-primary hover:text-white hover:border-primary transition-all shadow-sm"
                          >
                             <RotateCcw className="w-3.5 h-3.5" /> Reorder
                          </button>
                        ) : (
                          <div className="flex items-center gap-2">
                             {order.status === 'Pending' && (
                               <button 
                                 onClick={() => cancelOrder(order.id)}
                                 className="px-4 py-2.5 bg-rose-50 text-rose-500 rounded-xl text-[9px] font-black uppercase tracking-widest hover:bg-rose-500 hover:text-white transition-all shadow-sm"
                               >
                                  Cancel
                               </button>
                             )}
                             <button className="flex items-center gap-2 px-4 py-2.5 bg-primary text-white rounded-xl text-[9px] font-black uppercase tracking-widest shadow-lg shadow-primary/20 active:scale-95 transition-all">
                                Track Order <ChevronRight className="w-3.5 h-3.5" />
                             </button>
                          </div>
                        )}
                     </div>
                  </div>
               </div>

               {/* Tracking Summary (Only for Active) */}
               {activeTab === 'Active' && order.status !== 'Cancelled' && (
                 <div className="mt-6 pt-6 border-t border-slate-50">
                    <div className="flex items-center justify-between mb-3 text-[10px] font-black uppercase tracking-widest text-slate-400 px-1">
                       <span>Preparation Progress</span>
                       <span className="text-primary">
                          {order.status === 'Pending' ? '20%' : order.status === 'Cooking' ? '65%' : order.status === 'Ready' ? '95%' : '100%'} Completed
                       </span>
                    </div>
                    <div className="flex gap-1.5 h-2">
                       <div className={cn("flex-1 rounded-full", (order.status === 'Pending' || order.status === 'Cooking' || order.status === 'Ready') ? "bg-primary shadow-[0_0_10px_rgba(99,102,241,0.3)]" : "bg-slate-100")} />
                       <div className={cn("flex-1 rounded-full", (order.status === 'Cooking' || order.status === 'Ready') ? "bg-primary shadow-[0_0_10px_rgba(99,102,241,0.3)]" : "bg-slate-100")} />
                       <div className={cn("flex-1 rounded-full", (order.status === 'Cooking' || order.status === 'Ready') ? "bg-primary shadow-[0_0_10px_rgba(99,102,241,0.3)]" : "bg-slate-100", order.status === 'Cooking' && "opacity-40 animate-pulse")} />
                       <div className={cn("flex-1 rounded-full", (order.status === 'Ready') ? "bg-primary shadow-[0_0_10px_rgba(99,102,241,0.3)]" : "bg-slate-100")} />
                    </div>
                 </div>
               )}
            </div>
          ))
        )}
      </div>

      {/* Reward Ad */}
      <div className="card p-6 bg-gradient-to-br from-indigo-600 to-primary text-white border-none rounded-[2rem] shadow-2xl relative overflow-hidden group cursor-pointer lg:mb-4">
         <div className="absolute top-0 right-0 w-48 h-48 bg-white/10 rounded-full -mr-24 -mt-24 blur-3xl transition-transform group-hover:scale-110" />
         <div className="relative z-10 flex items-center gap-6">
            <div className="w-16 h-16 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center text-3xl shadow-xl">
               🎁
            </div>
            <div>
               <h4 className="text-lg lg:text-xl font-black uppercase tracking-tight leading-none mb-1">Earn 50 Points</h4>
               <p className="text-[10px] font-bold text-white/70 uppercase tracking-widest">Rate your previous orders to unlock rewards!</p>
            </div>
            <div className="ml-auto p-3 bg-white/10 rounded-full hover:bg-white/20 transition-all">
               <Star className="w-5 h-5 text-yellow-300" />
            </div>
         </div>
      </div>
    </div>
  );
};

export default CustomerOrders;
