import React, { useState } from 'react';
import { 
  Trash2, 
  Plus, 
  Minus, 
  ShoppingBag, 
  ChevronLeft, 
  CreditCard, 
  Ticket,
  ChevronRight,
  Sparkles,
  ArrowRight,
  Info
} from 'lucide-react';
import { cn } from '../utils/cn';
import { useNavigate } from 'react-router-dom';

const CustomerCart = () => {
  const navigate = useNavigate();
  
  // Mock Cart Data
  const [cartItems, setCartItems] = useState([
    { 
      id: 1, 
      itemId: 1, 
      name: "Margherita Pizza", 
      size: "Medium", 
      price: 299, 
      quantity: 1, 
      notes: "Extra cheese",
      image: '🍕'
    },
    { 
      id: 2, 
      itemId: 3, 
      name: "Cheese Burger", 
      size: "Regular", 
      price: 189, 
      quantity: 2, 
      notes: "",
      image: '🍔'
    }
  ]);

  const updateQuantity = (id, delta) => {
    setCartItems(prev => prev.map(item => 
      item.id === id ? { ...item, quantity: Math.max(1, item.quantity + delta) } : item
    ));
  };

  const removeItem = (id) => {
    setCartItems(prev => prev.filter(item => item.id !== id));
  };

  const subtotal = cartItems.reduce((acc, item) => acc + (item.price * item.quantity), 0);
  const tax = subtotal * 0.05; // 5% GST
  const serviceCharge = 25;
  const total = subtotal + tax + serviceCharge;

  if (cartItems.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-[70vh] text-center px-6">
        <div className="w-24 h-24 bg-slate-50 rounded-[2.5rem] flex items-center justify-center mb-6 shadow-inner">
           <ShoppingBag className="w-10 h-10 text-slate-200" />
        </div>
        <h2 className="text-2xl font-black text-text-primary uppercase tracking-tight">Your cart is empty</h2>
        <p className="text-slate-400 font-medium mt-2 max-w-[250px] leading-relaxed">Looks like you haven't added anything to your cart yet.</p>
        <button 
          onClick={() => navigate('/customer/menu')}
          className="mt-8 btn-primary px-10 py-4 rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-primary/20 active:scale-95 transition-all"
        >
           Browse Menu
        </button>
      </div>
    );
  }

  return (
    <div className="flex flex-col lg:flex-row h-full gap-8">
      {/* Left Side: Cart Items */}
      <div className="flex-1 space-y-6 overflow-y-auto scrollbar-hide pb-20 lg:pb-10">
        <div className="flex items-center justify-between px-1">
           <div className="flex items-center gap-3">
              <button onClick={() => navigate(-1)} className="p-2.5 bg-white rounded-xl shadow-sm border border-slate-100 lg:hidden">
                 <ChevronLeft className="w-5 h-5 text-text-primary" />
              </button>
              <h2 className="text-xl lg:text-2xl font-black text-text-primary uppercase tracking-tight">Review Order</h2>
           </div>
           <p className="text-[10px] font-black text-primary uppercase tracking-widest px-3 py-1 bg-primary/5 rounded-lg">{cartItems.length} Items</p>
        </div>

        <div className="space-y-4">
          {cartItems.map((item) => (
            <div key={item.id} className="card p-4 lg:p-5 bg-white border-none shadow-xl shadow-slate-100/50 flex gap-4 lg:gap-6 group transition-all hover:bg-slate-50">
               <div className="w-20 h-20 lg:w-24 lg:h-24 bg-slate-50 rounded-2xl flex items-center justify-center text-4xl shadow-inner group-hover:scale-105 transition-transform">
                  {item.image}
               </div>
               <div className="flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-start">
                       <h4 className="font-black text-text-primary text-sm lg:text-base uppercase tracking-tight leading-none mb-1 group-hover:text-primary transition-colors">{item.name}</h4>
                       <button 
                         onClick={() => removeItem(item.id)}
                         className="p-1.5 text-slate-300 hover:text-rose-500 transition-colors"
                       >
                          <Trash2 className="w-4 h-4" />
                       </button>
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                       <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{item.size}</span>
                       {item.notes && (
                         <div className="flex items-center gap-1 text-[8px] font-bold text-primary bg-primary/5 px-2 py-0.5 rounded-full uppercase tracking-wider">
                            <Sparkles className="w-2.5 h-2.5" />
                            {item.notes}
                         </div>
                       )}
                    </div>
                  </div>
                  <div className="flex items-center justify-between mt-4">
                     <p className="font-black text-text-primary text-sm lg:text-lg tracking-tighter">₹{item.price}</p>
                     <div className="flex items-center gap-4 p-1.5 bg-white border border-slate-100 rounded-xl shadow-sm">
                        <button 
                          onClick={() => updateQuantity(item.id, -1)}
                          className="w-7 h-7 flex items-center justify-center text-slate-400 hover:text-primary active:scale-90"
                        >
                           <Minus className="w-4 h-4" />
                        </button>
                        <span className="text-xs font-black text-text-primary w-2 text-center">{item.quantity}</span>
                        <button 
                          onClick={() => updateQuantity(item.id, 1)}
                          className="w-7 h-7 flex items-center justify-center text-slate-400 hover:text-primary active:scale-90"
                        >
                           <Plus className="w-4 h-4" />
                        </button>
                     </div>
                  </div>
               </div>
            </div>
          ))}
        </div>

        {/* Coupon Section */}
        <div className="card p-5 lg:p-6 bg-emerald-50 border-2 border-dashed border-emerald-200 rounded-[2rem] flex items-center justify-between group cursor-pointer active:scale-[0.98] transition-all">
           <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-white rounded-xl shadow-sm flex items-center justify-center text-emerald-500">
                 <Ticket className="w-6 h-6" />
              </div>
              <div>
                 <h4 className="text-sm font-black text-emerald-900 uppercase tracking-tight leading-none">Apply Coupon</h4>
                 <p className="text-[9px] font-bold text-emerald-600 uppercase tracking-widest mt-1">Unlock better deals!</p>
              </div>
           </div>
           <ChevronRight className="w-5 h-5 text-emerald-400 group-hover:translate-x-1 transition-transform" />
        </div>
      </div>

      {/* Right Side: Summary Card */}
      <div className="w-full lg:w-96 space-y-6">
        <div className="card p-6 lg:p-8 bg-white border-none shadow-2xl shadow-slate-200/50 rounded-[2.5rem] lg:rounded-[3rem] flex flex-col gap-8">
           <div>
              <h3 className="text-xl font-black text-text-primary uppercase tracking-tight mb-6 flex items-center gap-3">
                 <CreditCard className="w-6 h-6 text-primary" /> Bill Summary
              </h3>
              
              <div className="space-y-4">
                 <div className="flex justify-between items-center text-xs lg:text-sm font-bold text-slate-400 uppercase tracking-widest">
                    <span>Subtotal</span>
                    <span className="text-text-primary font-black">₹{subtotal.toFixed(0)}</span>
                 </div>
                 <div className="flex justify-between items-center text-xs lg:text-sm font-bold text-slate-400 uppercase tracking-widest">
                    <span>GST (5%)</span>
                    <span className="text-emerald-500 font-black">₹{tax.toFixed(0)}</span>
                 </div>
                 <div className="flex justify-between items-center text-xs lg:text-sm font-bold text-slate-400 uppercase tracking-widest">
                    <span>Service Fee</span>
                    <span className="text-text-primary font-black">₹{serviceCharge}</span>
                 </div>
                 <div className="h-px bg-slate-50 my-2" />
                 <div className="flex justify-between items-center">
                    <span className="text-sm lg:text-base font-black text-text-primary uppercase tracking-tight">Grand Total</span>
                    <span className="text-xl lg:text-3xl font-black text-primary tracking-tighter">₹{total.toFixed(0)}</span>
                 </div>
              </div>
           </div>

           <div className="p-4 bg-slate-50 rounded-2xl flex items-start gap-3">
              <Info className="w-4 h-4 text-primary shrink-0 mt-0.5" />
              <p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest leading-relaxed">By placing this order, you agree to our terms of service and payment policies.</p>
           </div>

           <button 
             onClick={() => {
               alert('Order Placed! Redirecting to tracking...');
               navigate('/customer/orders');
             }}
             className="w-full btn-primary py-4 lg:py-5 rounded-2xl lg:rounded-3xl flex items-center justify-center gap-3 text-sm font-black uppercase tracking-widest shadow-2xl shadow-primary/30 active:scale-95 transition-all group"
           >
              Place Order <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
           </button>
        </div>

        {/* Need Help Card */}
        <div className="card p-6 bg-slate-900 text-white border-none rounded-[2rem] shadow-xl relative overflow-hidden group cursor-pointer" onClick={() => navigate('/customer/support')}>
           <div className="absolute top-0 right-0 w-32 h-32 bg-primary/20 rounded-full -mr-16 -mt-16 blur-2xl" />
           <div className="relative z-10 flex items-center gap-4">
              <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-all">
                 <UtensilsCrossed className="w-6 h-6" />
              </div>
              <div>
                 <h4 className="text-sm font-black uppercase tracking-tight leading-none">Call Waiter</h4>
                 <p className="text-[9px] font-bold text-white/40 uppercase tracking-widest mt-1">Assistance at Table 05</p>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default CustomerCart;
