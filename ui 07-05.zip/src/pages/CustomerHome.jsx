import React, { useState } from 'react';
import { 
  Search, 
  UtensilsCrossed, 
  Star, 
  Clock, 
  ChevronRight, 
  Sparkles,
  ShoppingBag,
  History,
  Tag,
  MapPin,
  Bell
} from 'lucide-react';
import { cn } from '../utils/cn';
import { useMenu } from '../context/MenuContext';
import { useNavigate } from 'react-router-dom';

const CustomerHome = () => {
  const { items, categoriesList } = useMenu();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');

  const recommendedItems = items.filter(item => item.id <= 4);
  const todaysOffers = [
    { title: 'Flat 50% Off', desc: 'On all orders above ₹999', color: 'from-orange-500 to-rose-500', icon: '🔥' },
    { title: 'Free Dessert', desc: 'On your first order today', color: 'from-indigo-500 to-primary', icon: '🍰' }
  ];

  const activeOrder = {
    id: '#ORD-2026',
    status: 'Cooking',
    items: 3,
    time: 'Est: 12 mins',
    progress: 65
  };

  return (
    <div className="space-y-6 lg:space-y-8 pb-20 lg:pb-0">
      {/* Header / Welcome Section */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="badge bg-primary/10 text-primary border-none px-3 py-1 font-black text-[10px] uppercase tracking-widest">Dine-In • Table 05</span>
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          </div>
          <h1 className="text-2xl lg:text-3xl font-black text-text-primary tracking-tight leading-none uppercase">
            Good Afternoon, <span className="text-primary">Guest!</span>
          </h1>
          <p className="text-text-secondary mt-2 text-xs lg:text-sm font-medium">What's on your mind today? 🍕</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="p-3 bg-white rounded-2xl shadow-sm border border-slate-100 text-text-secondary hover:text-primary relative group">
            <Bell className="w-5 h-5" />
            <span className="absolute top-2.5 right-2.5 w-2 h-2 bg-primary rounded-full border-2 border-white shadow-sm" />
          </button>
          <div className="flex items-center gap-3 p-2 bg-white rounded-2xl shadow-sm border border-slate-100">
             <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center text-primary font-black">
                R
             </div>
             <div className="pr-2">
                <p className="text-[10px] font-black uppercase tracking-tight text-text-primary leading-none">1250</p>
                <p className="text-[8px] font-bold text-slate-400 uppercase mt-1 leading-none">Points</p>
             </div>
          </div>
        </div>
      </div>

      {/* Global Search */}
      <div className="relative group">
        <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300 group-focus-within:text-primary transition-colors" />
        <input 
          type="text" 
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search food, drinks, desserts..." 
          className="w-full pl-14 pr-6 py-4 lg:py-5 bg-white border-2 border-slate-50 focus:border-primary focus:bg-white rounded-2xl lg:rounded-3xl outline-none shadow-xl shadow-slate-100/50 text-sm font-bold transition-all"
        />
      </div>

      {/* Active Order Tracker */}
      {activeOrder && (
        <div className="card p-5 lg:p-6 bg-primary text-white border-none shadow-2xl shadow-primary/20 relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-48 h-48 bg-white/10 rounded-full -mr-24 -mt-24 blur-3xl" />
          <div className="relative z-10">
            <div className="flex justify-between items-start mb-4">
               <div>
                  <div className="flex items-center gap-2 mb-1">
                    <Clock className="w-4 h-4 text-white/60" />
                    <span className="text-[9px] font-black uppercase tracking-widest text-white/60">Active Order Tracker</span>
                  </div>
                  <h3 className="text-xl font-black uppercase tracking-tight">{activeOrder.status}...</h3>
               </div>
               <button onClick={() => navigate('/customer/orders')} className="p-2 bg-white/20 hover:bg-white/30 rounded-xl transition-all">
                 <ChevronRight className="w-5 h-5" />
               </button>
            </div>
            <div className="space-y-4">
              <div className="w-full h-2 bg-white/20 rounded-full overflow-hidden">
                <div className="h-full bg-white shadow-[0_0_15px_rgba(255,255,255,0.5)] transition-all duration-1000" style={{ width: `${activeOrder.progress}%` }} />
              </div>
              <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-widest">
                <span>{activeOrder.id} • {activeOrder.items} Items</span>
                <span className="text-white/80">{activeOrder.time}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Categories Grid */}
      <div className="space-y-4">
        <div className="flex justify-between items-center px-1">
           <h3 className="text-lg font-black uppercase tracking-tight">Categories</h3>
           <button onClick={() => navigate('/customer/menu')} className="text-[10px] font-black text-primary uppercase tracking-widest hover:underline">View All</button>
        </div>
        <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide -mx-1 px-1">
          {categoriesList.filter(c => c !== 'All').map((cat) => (
            <button 
              key={cat}
              onClick={() => navigate(`/customer/menu?category=${cat}`)}
              className="flex flex-col items-center gap-3 shrink-0 group"
            >
              <div className="w-16 h-16 lg:w-20 lg:h-20 bg-white rounded-3xl shadow-lg border border-slate-50 flex items-center justify-center text-3xl group-hover:bg-primary group-hover:border-primary transition-all active:scale-95">
                {cat === 'Pizza' ? '🍕' : cat === 'Burgers' ? '🍔' : cat === 'Pasta' ? '🍝' : cat === 'Drinks' ? '🥤' : '🍽️'}
              </div>
              <span className="text-[10px] font-black uppercase tracking-widest text-text-secondary group-hover:text-primary">{cat}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Offers & Banner */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
         {todaysOffers.map((offer) => (
           <div key={offer.title} className={cn("p-6 rounded-[2rem] relative overflow-hidden group cursor-pointer active:scale-[0.98] transition-all bg-gradient-to-br", offer.color)}>
              <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16 blur-2xl" />
              <div className="relative z-10 flex items-center justify-between">
                <div>
                  <h4 className="text-white text-xl font-black uppercase tracking-tight leading-none mb-1">{offer.title}</h4>
                  <p className="text-white/80 text-[10px] font-bold uppercase tracking-widest">{offer.desc}</p>
                </div>
                <div className="text-4xl">{offer.icon}</div>
              </div>
           </div>
         ))}
      </div>

      {/* Recommended Section */}
      <div className="space-y-4">
        <div className="flex justify-between items-center px-1">
           <h3 className="text-lg font-black uppercase tracking-tight">Chef's Recommendations</h3>
           <button onClick={() => navigate('/customer/menu')} className="text-[10px] font-black text-primary uppercase tracking-widest hover:underline">Full Menu</button>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {recommendedItems.map((item) => (
            <div 
              key={item.id} 
              onClick={() => navigate('/customer/menu')}
              className="card group cursor-pointer border-none shadow-xl shadow-slate-100/50 p-4 bg-white hover:bg-slate-50 transition-all active:scale-95 flex flex-col h-full"
            >
              <div className="h-32 lg:h-40 bg-slate-50 rounded-2xl flex items-center justify-center text-5xl mb-4 shadow-inner relative overflow-hidden">
                 {item.image}
                 <button className="absolute top-3 right-3 p-2 bg-white/80 backdrop-blur-md rounded-xl text-slate-300 hover:text-rose-500 shadow-sm transition-colors">
                    <Sparkles className="w-4 h-4" />
                 </button>
              </div>
              <div className="flex-1 space-y-1">
                <div className="flex items-center gap-1.5 mb-1">
                  <Star className="w-3 h-3 fill-yellow-500 text-yellow-500" />
                  <span className="text-[9px] font-black text-slate-400">4.8 (120+)</span>
                </div>
                <h4 className="font-black text-text-primary text-xs lg:text-sm uppercase tracking-tight leading-tight group-hover:text-primary transition-colors">{item.name}</h4>
                <p className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">{item.category}</p>
              </div>
              <div className="mt-4 flex items-center justify-between">
                <p className="text-sm lg:text-lg font-black text-text-primary tracking-tighter">₹{item.price}</p>
                <div className="w-8 h-8 lg:w-10 lg:h-10 bg-primary/10 text-primary rounded-xl flex items-center justify-center group-hover:bg-primary group-hover:text-white transition-all shadow-sm">
                   <ChevronRight className="w-5 h-5" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default CustomerHome;
