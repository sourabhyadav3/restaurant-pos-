import React, { useState } from 'react';
import { 
  Search, 
  Filter, 
  MoreVertical, 
  Eye, 
  Clock, 
  CheckCircle2, 
  Timer,
  ChevronRight,
  X,
  Printer,
  Download,
  Calendar,
  ChevronLeft,
  ShoppingBag,
  ExternalLink,
  MapPin,
  CreditCard,
  Sparkles
} from 'lucide-react';
import { createPortal } from 'react-dom';
import { cn } from '../utils/cn';

const Orders = () => {
  const [activeTab, setActiveTab] = useState('All');
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [sortBy, setSortBy] = useState(null);
  const [isPrinting, setIsPrinting] = useState(false);

  const handlePrint = () => {
    setIsPrinting(true);
    setTimeout(() => {
      setIsPrinting(false);
      alert('Receipt sent to printer!');
    }, 1500);
  };

  const handleFullAudit = () => {
    alert('Opening full audit log for ' + selectedOrder.id);
  };

  const orders = [
    { id: '#1024', type: 'Dine-in', table: 'T-05', status: 'Ready', amount: '₹450', time: '12:45 PM', items: 3, date: 'Today', customer: 'Rahul K.', payment: 'UPI' },
    { id: '#1025', type: 'Takeaway', table: '-', status: 'Cooking', amount: '₹120', time: '1:10 PM', items: 1, date: 'Today', customer: 'Guest', payment: 'Cash' },
    { id: '#1026', type: 'Dine-in', table: 'T-02', status: 'Pending', amount: '₹890', time: '1:15 PM', items: 5, date: 'Today', customer: 'Priya S.', payment: 'Card' },
    { id: '#1027', type: 'Delivery', table: '-', status: 'New', amount: '₹340', time: '1:20 PM', items: 2, date: 'Today', customer: 'Amit V.', payment: 'UPI' },
    { id: '#1028', type: 'Dine-in', table: 'T-08', status: 'Delivered', amount: '₹210', time: '1:05 PM', items: 2, date: 'Today', customer: 'Suresh M.', payment: 'Cash' },
    { id: '#1029', type: 'Takeaway', table: '-', status: 'Cooking', amount: '₹550', time: '1:12 PM', items: 4, date: 'Today', customer: 'Guest', payment: 'Card' },
    { id: '#1030', type: 'Dine-in', table: 'T-12', status: 'Ready', amount: '₹1,250', time: '12:30 PM', items: 6, date: 'Today', customer: 'Anjali R.', payment: 'UPI' },
  ];

  const getStatusStyle = (status) => {
    switch (status) {
      case 'New': return 'bg-blue-50 text-blue-600 border-blue-100';
      case 'Pending': return 'bg-orange-50 text-orange-600 border-orange-100';
      case 'Cooking': return 'bg-indigo-50 text-indigo-600 border-indigo-100';
      case 'Ready': return 'bg-emerald-50 text-emerald-600 border-emerald-100';
      case 'Delivered': return 'bg-slate-50 text-slate-500 border-slate-100';
      default: return 'bg-slate-50 text-text-secondary border-border';
    }
  };

  const processedOrders = orders
    .filter(o => {
      const matchesTab = activeTab === 'All' || o.status === activeTab;
      const matchesSearch = o.id.toLowerCase().includes(searchQuery.toLowerCase()) || o.customer.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesTab && matchesSearch;
    })
    .sort((a, b) => {
      if (!sortBy) return 0;
      if (sortBy === 'Amount') {
        const amtA = parseInt(a.amount.replace('₹', '').replace(',', ''));
        const amtB = parseInt(b.amount.replace('₹', '').replace(',', ''));
        return amtB - amtA;
      }
      if (sortBy === 'Date') return a.time.localeCompare(b.time);
      if (sortBy === 'Payment') return a.payment.localeCompare(b.payment);
      if (sortBy === 'Table') return a.table.localeCompare(b.table);
      return 0;
    });

  return (
    <div className="space-y-6 relative h-full flex flex-col overflow-hidden bg-background">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 shrink-0 px-1">
          <div>
            <h2 className="text-2xl md:text-3xl font-black tracking-tight text-text-primary uppercase tracking-tight leading-none">Orders</h2>
            <p className="text-text-secondary mt-2 text-[10px] md:text-sm font-medium leading-none italic">Manage order lifecycle and audits.</p>
          </div>
          
          <div className="flex flex-col sm:flex-row items-center gap-3 w-full lg:w-auto">
            <div className="relative group w-full sm:w-64">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-text-secondary group-focus-within:text-primary" />
              <input 
                type="text" 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Find ticket..." 
                className="w-full pl-10 pr-4 py-3.5 bg-white border border-slate-100 rounded-xl lg:rounded-2xl text-[10px] font-black uppercase tracking-widest focus:ring-4 focus:ring-primary/10 outline-none shadow-sm"
              />
            </div>
            <button 
              onClick={() => setShowFilters(!showFilters)}
              className={cn(
                "flex items-center justify-center gap-2.5 px-6 py-3.5 w-full sm:w-auto rounded-xl lg:rounded-2xl text-[9px] font-black uppercase tracking-widest shadow-sm border-2 transition-all active:scale-95",
                showFilters ? "bg-primary text-white border-primary shadow-lg shadow-primary/20" : "bg-white border-slate-50 text-text-secondary hover:border-primary/20"
              )}
            >
              <Filter className="w-4 h-4" /> {showFilters ? 'Active' : 'Filters'}
            </button>
          </div>
        </div>

        {showFilters && (
          <div className="overflow-hidden px-1">
            <div className="p-4 lg:p-6 bg-slate-50 rounded-[1.5rem] lg:rounded-[2rem] border border-slate-100 flex flex-wrap gap-3 lg:gap-4">
              {['Date', 'Amount', 'Payment', 'Table'].map(f => (
                <button 
                  key={f} 
                  onClick={() => setSortBy(sortBy === f ? null : f)}
                  className={cn(
                    "px-3 lg:px-4 py-2 border rounded-lg lg:rounded-xl text-[8px] lg:text-[9px] font-black uppercase tracking-widest transition-all",
                    sortBy === f ? "bg-primary text-white border-primary shadow-lg" : "bg-white border-slate-200 hover:border-primary/30"
                  )}
                >
                  By {f}
                </button>
              ))}
              <button 
                onClick={() => {
                  setSortBy(null);
                  setShowFilters(false);
                }} 
                className="px-4 py-2 text-[8px] lg:text-[9px] font-black uppercase tracking-widest text-primary ml-auto hover:underline"
              >
                Clear
              </button>
            </div>
          </div>
        )}

        {/* Modern Tab System */}
        <div className="flex gap-2 lg:gap-2.5 overflow-x-auto pb-2 scrollbar-hide shrink-0 px-1">
          {['All', 'New', 'Pending', 'Cooking', 'Ready', 'Delivered'].map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={cn(
                "px-5 lg:px-6 py-2 lg:py-2.5 rounded-lg lg:rounded-xl text-[8px] lg:text-[9px] font-black uppercase tracking-widest border-2 transition-all shrink-0",
                activeTab === tab 
                  ? "bg-primary text-white border-primary shadow-lg shadow-primary/20" 
                  : "bg-white text-text-secondary border-transparent hover:border-primary/20"
              )}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Responsive Order Display */}
        <div className="flex-1 overflow-hidden flex flex-col">
          {/* Desktop Table */}
          <div className="hidden md:block card p-0 overflow-hidden flex-1 shadow-2xl shadow-slate-200/50 border-none bg-white rounded-[2.5rem]">
            <div className="h-full overflow-y-auto scrollbar-hide">
              <table className="w-full">
                <thead className="sticky top-0 z-10">
                  <tr className="text-left text-text-secondary text-[9px] font-black uppercase tracking-[0.2em] border-b border-slate-50 bg-slate-50/50">
                    <th className="px-8 py-5">Ticket</th>
                    <th className="px-8 py-5">Customer / Table</th>
                    <th className="px-8 py-5">Type</th>
                    <th className="px-8 py-5">Status</th>
                    <th className="px-8 py-5 text-right">Amount</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {processedOrders.map((order) => (
                    <tr 
                      key={order.id} 
                      className="text-sm hover:bg-slate-50 group cursor-pointer"
                      onClick={() => setSelectedOrder(order)}
                    >
                      <td className="px-8 py-5">
                        <div className="flex items-center gap-4">
                          <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-lg border border-slate-50">
                              <ShoppingBag className="w-5 h-5 text-primary" />
                          </div>
                          <div>
                              <span className="font-black text-text-primary text-base tracking-tight">{order.id}</span>
                              <p className="text-[9px] font-black text-slate-300 uppercase tracking-widest mt-1">{order.time}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-8 py-5">
                        <p className="font-black text-text-primary text-sm leading-tight">{order.customer}</p>
                        <p className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] mt-1.5">
                          {order.table !== '-' ? `TABLE ${order.table}` : 'WALK-IN'}
                        </p>
                      </td>
                      <td className="px-8 py-5">
                        <div className={cn(
                          "badge font-black uppercase tracking-wider border text-[8px] px-2 py-1",
                          order.type === 'Dine-in' ? "bg-indigo-50 text-primary border-indigo-100" : 
                          order.type === 'Takeaway' ? "bg-orange-50 text-orange-600 border-orange-100" : "bg-emerald-50 text-emerald-600 border-emerald-100"
                        )}>
                          {order.type}
                        </div>
                      </td>
                      <td className="px-8 py-5">
                        <span className={cn("badge font-black border py-1 px-2 text-[8px]", getStatusStyle(order.status))}>
                          {order.status}
                        </span>
                      </td>
                      <td className="px-8 py-5 text-right">
                        <div className="flex items-center justify-end gap-2 font-black text-text-primary text-base tracking-tight">
                            {order.amount}
                            <ChevronRight className="w-4 h-4 text-slate-200 group-hover:text-primary" />
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Mobile Cards */}
          <div className="md:hidden flex-1 overflow-y-auto space-y-4 pr-1 scrollbar-hide pb-10">
            {processedOrders.map((order) => (
              <div 
                key={order.id}
                onClick={() => setSelectedOrder(order)}
                className="bg-white p-5 rounded-[2rem] shadow-xl shadow-slate-200/50 border border-slate-50 flex flex-col gap-4"
              >
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-indigo-50 rounded-xl flex items-center justify-center text-primary">
                        <ShoppingBag className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-black text-lg tracking-tight">{order.id}</h4>
                        <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{order.time}</p>
                      </div>
                  </div>
                  <span className={cn("badge font-black border py-1 px-3 text-[8px] rounded-lg", getStatusStyle(order.status))}>
                      {order.status}
                  </span>
                </div>
                <div className="flex justify-between items-end border-t border-slate-50 pt-4">
                  <div>
                      <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Customer</p>
                      <p className="font-black text-sm text-text-primary">{order.customer}</p>
                  </div>
                  <div className="text-right">
                      <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Settlement</p>
                      <p className="font-black text-lg text-primary tracking-tighter">{order.amount}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
          
        {/* Footer */}
        <div className="px-6 md:px-10 py-6 border-t border-slate-50 flex flex-col md:flex-row items-center justify-between bg-slate-50/30 gap-6 shrink-0 mt-4 md:mt-0">
          <div className="flex items-center gap-4 md:gap-6">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Displaying <span className="text-text-primary">{processedOrders.length}</span> entries</p>
              <div className="h-4 w-[2px] bg-slate-200 hidden md:block" />
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] hidden md:block">Total Log <span className="text-text-primary">124</span></p>
          </div>
          <div className="flex gap-4 w-full md:w-auto">
            <button 
              disabled={currentPage === 1}
              onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
              className="flex-1 md:flex-none h-12 md:w-12 bg-white border-2 border-slate-100 rounded-2xl flex items-center justify-center hover:bg-primary hover:text-white transition-all shadow-sm disabled:opacity-30 disabled:cursor-not-allowed group"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button 
              onClick={() => setCurrentPage(prev => prev + 1)}
              className="flex-1 md:flex-none h-12 md:w-12 bg-white border-2 border-slate-100 rounded-2xl flex items-center justify-center hover:bg-primary hover:text-white transition-all shadow-sm group"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
        </div>
      </div>

      {/* Side Audit Panel */}
      {createPortal(
        <>
          {selectedOrder && (
            <div className="fixed inset-0 z-[200] flex items-center justify-center p-0 sm:p-6">
              <div 
                onClick={() => setSelectedOrder(null)}
                className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
              />
              <div 
                className="relative w-full max-w-[520px] max-h-[90vh] sm:max-h-[85vh] bg-white shadow-2xl z-[201] flex flex-col rounded-t-[2.5rem] sm:rounded-[2.5rem] overflow-hidden self-end sm:self-center"
              >

                <div className="px-6 py-5 border-b border-slate-50 flex justify-between items-center bg-slate-50/30 shrink-0">
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 bg-primary rounded-2xl flex items-center justify-center text-white shadow-xl relative group">
                        <ShoppingBag className="w-6 h-6" />
                        <div className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-emerald-500 rounded-full border-2 border-white" />
                    </div>
                    <div>
                      <h3 className="text-xl font-black tracking-tight uppercase">Order Audit</h3>
                      <p className="text-text-secondary font-black uppercase tracking-widest text-[9px] mt-1 flex items-center gap-2">
                          {selectedOrder.id} <span className="w-1 h-1 rounded-full bg-slate-200" /> {selectedOrder.time}
                      </p>
                    </div>
                  </div>
                  <button 
                    onClick={() => setSelectedOrder(null)} 
                    className="p-3 hover:bg-white rounded-2xl border border-transparent hover:border-slate-100 shadow-sm group"
                  >
                    <X className="w-6 h-6 text-text-secondary" />
                  </button>
                </div>

                <div className="flex-1 overflow-y-auto px-6 py-8 space-y-10 scrollbar-hide">
                    <div className="p-6 bg-slate-50 rounded-[2.5rem] border border-slate-100 flex flex-col gap-8 relative overflow-hidden">
                      <div className="flex items-center justify-between relative z-10">
                          <div className="flex items-center gap-4">
                            <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center text-2xl font-black shadow-xl border border-slate-50 text-primary">
                                {selectedOrder.customer.charAt(0)}
                            </div>
                            <div>
                                <h4 className="text-xl font-black tracking-tight leading-none">{selectedOrder.customer}</h4>
                                <p className="text-[10px] font-black text-text-secondary flex items-center gap-2 mt-2 uppercase tracking-widest">
                                  <MapPin className="w-3 h-3 text-primary" /> {selectedOrder.type}
                                </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <span className={cn(
                              "badge px-4 py-1.5 font-black uppercase tracking-widest border-2 text-[8px] rounded-xl shadow-sm", 
                              getStatusStyle(selectedOrder.status)
                            )}>
                                {selectedOrder.status}
                            </span>
                          </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4 pt-6 border-t border-white relative z-10">
                         <div className="p-5 bg-white/60 rounded-2xl shadow-sm border border-white">
                            <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-2">Settlement</p>
                            <div className="flex items-center gap-2">
                                <div className="w-8 h-8 bg-indigo-50 rounded-lg flex items-center justify-center text-primary">
                                  <CreditCard className="w-4 h-4" />
                                </div>
                                <p className="text-xs font-black text-text-primary uppercase tracking-tight">{selectedOrder.payment}</p>
                            </div>
                          </div>
                         <div className="p-5 bg-white/60 rounded-2xl shadow-sm border border-white">
                            <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-2">Priority</p>
                            <div className="flex items-center gap-2">
                                <div className="w-8 h-8 bg-orange-50 rounded-lg flex items-center justify-center text-orange-600">
                                  <Timer className="w-4 h-4" />
                                </div>
                                <p className="text-xs font-black text-text-primary uppercase tracking-tight">Standard</p>
                            </div>
                          </div>
                      </div>
                      <Sparkles className="absolute -bottom-10 -right-10 w-44 h-44 text-primary opacity-[0.05] -rotate-12" />
                    </div>

                    <div className="space-y-6">
                      <div className="flex items-center justify-between px-2">
                          <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.25em]">Kitchen Token List</h4>
                          <span className="text-[9px] font-black text-primary px-3 py-1 bg-indigo-50 rounded-full tracking-widest">{selectedOrder.items} ITEMS</span>
                      </div>
                      <div className="space-y-4">
                          {[1, 2, 3].map((_, i) => (
                            <div 
                              key={i} 
                              className="flex justify-between items-center group p-4 bg-slate-50/50 hover:bg-slate-50 rounded-[1.5rem] border border-transparent hover:border-slate-100 shadow-sm"
                            >
                              <div className="flex items-center gap-4">
                                  <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center font-black text-base border border-slate-50 shadow-sm text-primary">
                                    {i === 0 ? 2 : 1}<span className="text-[10px] ml-0.5">x</span>
                                  </div>
                                  <div>
                                    <p className="font-black text-text-primary text-sm leading-none transition-colors">{i === 0 ? 'Pepperoni Pizza' : i === 1 ? 'Garlic Bread' : 'Diet Coke'}</p>
                                    <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mt-2 flex items-center gap-1.5">
                                        <Sparkles className="w-2.5 h-2.5 opacity-40" /> Unit: ₹{i === 0 ? 399 : i === 1 ? 149 : 49}
                                    </p>
                                  </div>
                              </div>
                              <p className="font-black text-text-primary text-lg tracking-tighter">₹{i === 0 ? 798 : i === 1 ? 149 : 49}</p>
                            </div>
                          ))}
                      </div>
                    </div>

                    <div className="p-6 bg-primary rounded-[2.5rem] text-white shadow-2xl relative overflow-hidden group">
                      <div className="space-y-4 relative z-10">
                          <div className="flex justify-between text-slate-500 text-[10px] font-black uppercase tracking-[0.2em]">
                            <span>Subtotal Gross</span>
                            <span className="text-white">₹{parseInt(selectedOrder.amount.replace('₹','').replace(',','')) - 45}</span>
                          </div>
                          <div className="flex justify-between text-slate-500 text-[10px] font-black uppercase tracking-[0.2em]">
                            <span>Govt Tax (GST 5%)</span>
                            <span className="text-white">₹45.00</span>
                          </div>
                          <div className="pt-8 mt-4 border-t border-primary/20 flex justify-between items-end">
                            <div>
                                <p className="text-slate-500 text-[8px] font-black uppercase tracking-[0.3em] mb-2">Net Settlement</p>
                                <div className="flex items-baseline gap-2">
                                  <h4 className="text-4xl font-black text-primary tracking-tighter">{selectedOrder.amount}</h4>
                                  <span className="text-[10px] font-black text-primary/40 uppercase tracking-widest">INR</span>
                                </div>
                            </div>
                            <div className="badge bg-emerald-500/20 text-emerald-500 border border-emerald-500/20 font-black px-5 py-2 rounded-xl shadow-lg text-[10px] uppercase tracking-widest">
                                PAID
                            </div>
                          </div>
                      </div>
                      <div className="absolute -top-10 -left-10 w-40 h-40 bg-primary/10 rounded-full blur-[80px]" />
                    </div>
                </div>

                  <div className="px-6 py-6 border-t border-slate-50 flex flex-col sm:flex-row gap-4 bg-white shrink-0 relative z-20 mb-0">
                    <button 
                      onClick={handlePrint}
                      disabled={isPrinting}
                      className="flex-1 py-4 border-2 border-slate-100 rounded-2xl flex items-center justify-center gap-3 text-[10px] font-black uppercase tracking-widest hover:bg-slate-50 shadow-sm disabled:opacity-50"
                    >
                      {isPrinting ? (
                        <div className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full" />
                      ) : <Printer className="w-5 h-5 text-slate-400" />}
                      {isPrinting ? 'Processing...' : 'Print Receipt'}
                    </button>
                    <button 
                      onClick={handleFullAudit}
                      className="flex-1 btn-primary py-4 rounded-2xl flex items-center justify-center gap-3 text-[10px] font-black uppercase tracking-widest shadow-2xl shadow-primary/30"
                    >
                      <ExternalLink className="w-5 h-5" /> Full Audit
                    </button>
                </div>
              </div>
            </div>
          )}
        </>,
        document.body
      )}
    </div>
  );
};

export default Orders;
