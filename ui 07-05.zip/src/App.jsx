import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth, roles } from './context/AuthContext';
import { MenuProvider } from './context/MenuContext';
import MainLayout from './layouts/MainLayout';
import Dashboard from './pages/Dashboard';
import Tables from './pages/Tables';
import POS from './pages/POS';
import Orders from './pages/Orders';
import Kitchen from './pages/Kitchen';
import Menu from './pages/Menu';
import Staff from './pages/Staff';
import Reports from './pages/Reports';
import Settings from './pages/Settings';
import Login from './pages/Login';

const ProtectedRoute = ({ children, allowedRoles }) => {
  const { user } = useAuth();
  
  if (!user) return <Navigate to="/login" />;
  if (allowedRoles && !allowedRoles.includes(user.role)) {
    // Show Access Denied or redirect according to RBAC.md
    return <Navigate to="/" />; 
  }
  
  return <MainLayout>{children}</MainLayout>;
};

const ThemeHandler = () => {
  React.useEffect(() => {
    const savedTheme = localStorage.getItem('pos-theme') || 'indigo';
    const themes = {
      indigo: { primary: '#6366F1', dark: '#4F46E5', light: '#EEF2FF' },
      rose: { primary: '#F43F5E', dark: '#E11D48', light: '#FFF1F2' },
      emerald: { primary: '#10B981', dark: '#059669', light: '#ECFDF5' },
      orange: { primary: '#F59E0B', dark: '#D97706', light: '#FFFBEB' },
      purple: { primary: '#9333EA', dark: '#7E22CE', light: '#FAF5FF' }
    };

    const theme = themes[savedTheme];
    if (theme) {
      document.documentElement.style.setProperty('--color-primary', theme.primary);
      document.documentElement.style.setProperty('--color-primary-dark', theme.dark);
      document.documentElement.style.setProperty('--color-primary-light', theme.light);
    }
  }, []);
  return null;
};

function App() {
  return (
    <MenuProvider>
      <AuthProvider>
        <ThemeHandler />
        <Router>
          <Routes>
            <Route path="/login" element={<Login />} />
            
            <Route path="/" element={
              <ProtectedRoute allowedRoles={[roles.ADMIN, roles.MANAGER]}>
                <Dashboard />
              </ProtectedRoute>
            } />
            
            <Route path="/tables" element={
              <ProtectedRoute allowedRoles={[roles.ADMIN, roles.MANAGER, roles.WAITER]}>
                <Tables />
              </ProtectedRoute>
            } />
            
            <Route path="/pos" element={
              <ProtectedRoute allowedRoles={[roles.ADMIN, roles.MANAGER, roles.WAITER, roles.CASHIER]}>
                <POS />
              </ProtectedRoute>
            } />
            
            <Route path="/orders" element={
              <ProtectedRoute allowedRoles={[roles.ADMIN, roles.MANAGER, roles.WAITER, roles.CHEF, roles.CASHIER]}>
                <Orders />
              </ProtectedRoute>
            } />
            
            <Route path="/kitchen" element={
              <ProtectedRoute allowedRoles={[roles.ADMIN, roles.MANAGER, roles.CHEF]}>
                <Kitchen />
              </ProtectedRoute>
            } />
            
            <Route path="/menu" element={
              <ProtectedRoute allowedRoles={[roles.ADMIN, roles.MANAGER]}>
                <Menu />
              </ProtectedRoute>
            } />
            
            <Route path="/staff" element={
              <ProtectedRoute allowedRoles={[roles.ADMIN]}>
                <Staff />
              </ProtectedRoute>
            } />
            
            <Route path="/reports" element={
              <ProtectedRoute allowedRoles={[roles.ADMIN, roles.MANAGER]}>
                <Reports />
              </ProtectedRoute>
            } />
            
            <Route path="/settings" element={
              <ProtectedRoute allowedRoles={[roles.ADMIN]}>
                <Settings />
              </ProtectedRoute>
            } />
            
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </Router>
      </AuthProvider>
    </MenuProvider>
  );
}

export default App;
