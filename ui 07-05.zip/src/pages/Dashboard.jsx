import React, { useState } from 'react';
import { 
  TrendingUp, 
  ShoppingBag, 
  Users, 
  Clock,
  ArrowUpRight,
  ArrowDownRight,
  MoreVertical,
  ChevronRight,
  Calendar,
  Filter,
  X,
  Download,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  FileText,
  Plus,
  Sparkles
} from 'lucide-react';
import { cn } from '../utils/cn';
import { useMenu, categoryIconMap } from '../context/MenuContext';

const Dashboard = () => {
  const { categoriesList, addItem } = useMenu();
  const [selectedStat, setSelectedStat] = useState(null);
  const [activeFilter, setActiveFilter] = useState('All');
  
  // New States
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [showAddItemModal, setShowAddItemModal] = useState(false);
  const [newItemIcon, setNewItemIcon] = useState('🍽️');
  const [newItemCategory, setNewItemCategory] = useState('');
  const [toast, setToast] = useState(null);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [selectedItem, setSelectedItem] = useState(null);
  const [showTopSellersMenu, setShowTopSellersMenu] = useState(false);
  const [orders, setOrders] = useState([
    { id: 124, table: 'T-03', type: 'Dine-in', items: 'Pizza x2, Coke x1', status: 'Cooking', time: '2m ago', amount: '₹750' },
    { id: 125, table: 'Takeaway', type: 'Takeaway', items: 'Burger x1, Fries x1', status: 'Pending', time: '5m ago', amount: '₹320' },
    { id: 126, table: 'T-12', type: 'Dine-in', items: 'Pasta x1, Wine x2', status: 'Ready', time: '8m ago', amount: '₹1,200' },
    { id: 127, table: 'Delivery', type: 'Delivery', items: 'Steak x2, Salad x1', status: 'Cooking', time: '12m ago', amount: '₹2,450' },
    { id: 128, table: 'T-05', type: 'Dine-in', items: 'Pizza x1, Juice x2', status: 'Pending', time: '15m ago', amount: '₹540' },
  ]);

  const [topSellers, setTopSellers] = useState([
    { name: 'Margherita Pizza', sales: 84, total: 100, price: '₹299', icon: '🍕', category: 'Pizza' },
    { name: 'Chicken Burger', sales: 65, total: 100, price: '₹189', icon: '🍔', category: 'Burger' },
    { name: 'Cheese Pasta', sales: 42, total: 100, price: '₹349', icon: '🍝', category: 'Pasta' },
    { name: 'Iced Coffee', sales: 38, total: 100, price: '₹129', icon: '☕', category: 'Drinks' },
  ]);

  const stats = [
    { id: 'revenue', name: 'Today Revenue', value: '₹45,230', icon: TrendingUp, change: '+12.5%', isUp: true, color: 'bg-indigo-50 text-primary' },
    { id: 'orders', name: 'Total Orders', value: '154', icon: ShoppingBag, change: '+8.2%', isUp: true, color: 'bg-emerald-50 text-emerald-600' },
    { id: 'tables', name: 'Active Tables', value: '12/20', icon: Users, change: '60% Occupancy', isUp: null, color: 'bg-orange-50 text-orange-600' },
    { id: 'prep', name: 'Avg. Prep Time', value: '18 min', icon: Clock, change: '-2 min', isUp: true, color: 'bg-rose-50 text-rose-600' },
  ];

  const filteredOrders = activeFilter === 'All' ? orders : orders.filter(o => o.type === activeFilter);

  const showToastMessage = (message, type = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  const handleAddItem = (newItem) => {
    addItem(newItem);
    setShowAddItemModal(false);
    setNewItemIcon('🍽️');
    setNewItemCategory('');
    showToastMessage('Item added to POS menu successfully');
  };

  const updateAutoIcon = (category) => {
    const normalized = category.toLowerCase().trim().replace(/s$/, '');
    const mappedIcon = categoryIconMap[normalized];
    if (mappedIcon) {
      setNewItemIcon(mappedIcon);
    } else {
      const partialMatch = Object.keys(categoryIconMap).find(key => normalized.includes(key));
      setNewItemIcon(partialMatch ? categoryIconMap[partialMatch] : '🍽️');
    }
  };

  const handleExportCSV = () => {
    const csvContent = "data:text/csv;charset=utf-8," 
      + "Metric,Value\n"
      + stats.map(s => `${s.name},${s.value}`).join("\n");
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "restaurant-dashboard-report.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToastMessage("Report generated successfully");
  };

  const updateOrderStatus = (id, newStatus) => {
    setOrders(orders.map(o => o.id === id ? { ...o, status: newStatus } : o));
    showToastMessage(`Order #${id} marked as ${newStatus}`);
    if (newStatus === 'Delivered') setSelectedOrder(null);
  };

  return (
    <div className="space-y-5 relative">
      {/* Toast Feedback */}
      {toast && (
        <div 
          className={cn(
            "fixed top-4 left-1/2 -translate-x-1/2 z-[300] px-6 py-3 rounded-2xl shadow-2xl flex items-center gap-3 font-black text-[10px] uppercase tracking-widest border",
            toast.type === 'success' ? "bg-primary border-primary/20 text-white" : "bg-primary border-primary/20 text-white"
          )}
        >
          {toast.type === 'success' ? <CheckCircle2 className="w-4 h-4 text-white" /> : <AlertCircle className="w-4 h-4 text-white" />}
          {toast.message}
        </div>
      )}

      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-xl lg:text-2xl font-black tracking-tight text-text-primary uppercase tracking-[0.05em]">Operational Hub</h2>
          <p className="text-text-secondary mt-1 text-xs lg:text-sm font-medium flex items-center gap-2">
            <Calendar className="w-4 h-4 text-primary" /> Wednesday, May 6, 2026
          </p>
        </div>
        <div className="flex flex-wrap gap-2 w-full md:w-auto">
          <button onClick={() => setShowAddItemModal(true)} className="flex-1 md:flex-none btn-primary py-2 px-4 lg:px-5 bg-primary border-primary hover:bg-primary/90 shadow-xl shadow-primary/20 text-[10px] lg:text-xs whitespace-nowrap">
             <Plus className="w-3.5 h-3.5 lg:w-4 lg:h-4" /> Add Item
          </button>
          <button onClick={() => setShowFilterModal(true)} className="flex-1 md:flex-none btn-secondary py-2 hover:border-primary/20 text-[10px] lg:text-xs px-4 whitespace-nowrap">
             <Filter className="w-3.5 h-3.5 lg:w-4 lg:h-4" /> Filter
          </button>
          <button onClick={handleExportCSV} className="flex-1 md:flex-none btn-primary py-2 px-4 lg:px-5 text-[10px] lg:text-xs whitespace-nowrap">
             <Download className="w-3.5 h-3.5 lg:w-4 lg:h-4" /> Export
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {stats.map((stat) => (
          <div 
            key={stat.id}
            onClick={() => setSelectedStat(stat)}
            className="card card-interactive cursor-pointer group relative overflow-hidden p-4 border border-slate-100 shadow-sm"
          >
            <div className="flex items-start justify-between relative z-10 mb-5">
              <p className="text-text-secondary text-xs font-semibold">{stat.name}</p>
              <div className="text-primary opacity-60">
                <stat.icon className="w-5 h-5 stroke-[1.5]" />
              </div>
            </div>
            <div className="flex items-end justify-between relative z-10">
              <h3 className="text-2xl font-black text-text-primary tracking-tighter">{stat.value}</h3>
              {stat.isUp !== null && (
                <div className={cn(
                  "badge px-2.5 py-1 rounded-lg text-[10px] font-bold flex items-center gap-1",
                  stat.isUp ? "bg-emerald-50 text-emerald-600" : "bg-rose-50 text-rose-600"
                )}>
                  {stat.isUp ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                  {stat.change}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">
        {/* Live Orders Feed */}
        <div className="xl:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 lg:gap-3">
               <h3 className="text-base lg:text-lg font-black tracking-tight uppercase tracking-wider">Live Orders Feed</h3>
               <div className="flex items-center gap-1.5 px-2 py-0.5 bg-emerald-50 text-emerald-600 rounded-full border border-emerald-100">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                  <span className="text-[7px] lg:text-[8px] font-black uppercase tracking-widest">Real-time</span>
               </div>
            </div>
            <div className="flex gap-1 lg:gap-1.5 bg-slate-50 p-1 rounded-xl overflow-x-auto scrollbar-hide max-w-[200px] sm:max-w-none">
              {['All', 'Dine-in', 'Takeaway', 'Delivery'].map(f => (
                <button 
                  key={f}
                  onClick={() => setActiveFilter(f)}
                  className={cn(
                    "px-2.5 lg:px-3 py-1.5 rounded-lg text-[9px] lg:text-[10px] font-black uppercase tracking-widest whitespace-nowrap",
                    activeFilter === f ? "bg-white text-primary shadow-sm" : "text-slate-400 hover:text-text-primary"
                  )}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>

          <div className="card p-0 overflow-hidden shadow-2xl shadow-slate-200/50 bg-white">
            {/* Desktop Table View */}
            <div className="hidden lg:block overflow-x-auto scrollbar-hide">
              <table className="w-full">
                <thead>
                  <tr className="text-left text-text-secondary text-[9px] font-black uppercase tracking-[0.2em] border-b border-slate-50 bg-slate-50/50">
                    <th className="px-6 py-4">Identity</th>
                    <th className="px-6 py-4">Location</th>
                    <th className="px-6 py-4">Composition</th>
                    <th className="px-6 py-4">State</th>
                    <th className="px-6 py-4 text-right">Value</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {filteredOrders.map((order) => (
                    <tr 
                      onClick={() => setSelectedOrder(order)}
                      key={order.id} 
                      className="text-xs hover:bg-slate-50/80 group cursor-pointer border-b border-slate-50 transition-colors"
                    >
                      <td className="px-6 py-4 font-black text-text-primary">#{order.id}</td>
                      <td className="px-6 py-4">
                         <div className="flex flex-col">
                            <span className="font-bold text-text-primary">{order.table}</span>
                            <span className="text-[9px] text-text-secondary uppercase font-black tracking-widest mt-0.5">{order.type}</span>
                         </div>
                      </td>
                      <td className="px-6 py-4">
                         <p className="text-text-primary font-bold tracking-tight">{order.items}</p>
                         <p className="text-[10px] text-text-secondary mt-0.5 font-medium">{order.time}</p>
                      </td>
                      <td className="px-6 py-4">
                        <span className={cn(
                          "badge border px-3 py-1 text-[9px] font-black uppercase tracking-widest",
                          order.status === 'Cooking' ? "bg-orange-50 text-orange-600 border-orange-100" : 
                          order.status === 'Pending' ? "bg-indigo-50 text-primary border-indigo-100" : "bg-emerald-50 text-emerald-600 border-emerald-100"
                        )}>
                          {order.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-right">
                         <div className="flex items-center justify-end gap-2 font-black text-text-primary text-sm">
                            {order.amount}
                            <ChevronRight className="w-3.5 h-3.5 text-slate-300 group-hover:text-primary transition-transform group-hover:translate-x-0.5" />
                         </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Mobile Card View */}
            <div className="lg:hidden divide-y divide-slate-50">
               {filteredOrders.map((order) => (
                 <div 
                   key={order.id}
                   onClick={() => setSelectedOrder(order)}
                   className="p-4 active:bg-slate-50 transition-colors"
                 >
                   <div className="flex justify-between items-start mb-3">
                      <div className="flex items-center gap-2">
                         <span className="text-[10px] font-black text-primary bg-indigo-50 px-2 py-0.5 rounded-lg">#{order.id}</span>
                         <span className="text-xs font-black text-text-primary uppercase tracking-tight">{order.table}</span>
                      </div>
                      <span className={cn(
                        "badge border px-2.5 py-1 text-[8px] font-black uppercase tracking-widest",
                        order.status === 'Cooking' ? "bg-orange-50 text-orange-600 border-orange-100" : 
                        order.status === 'Pending' ? "bg-indigo-50 text-primary border-indigo-100" : "bg-emerald-50 text-emerald-600 border-emerald-100"
                      )}>
                        {order.status}
                      </span>
                   </div>
                   <div className="flex justify-between items-end">
                      <div className="space-y-1">
                         <p className="text-[11px] font-bold text-text-primary tracking-tight line-clamp-1">{order.items}</p>
                         <div className="flex items-center gap-2">
                            <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest">{order.type}</span>
                            <span className="w-1 h-1 rounded-full bg-slate-300" />
                            <span className="text-[8px] font-bold text-slate-400">{order.time}</span>
                         </div>
                      </div>
                      <div className="flex items-center gap-1.5 font-black text-text-primary text-xs">
                         {order.amount}
                         <ChevronRight className="w-3.5 h-3.5 text-slate-300" />
                      </div>
                   </div>
                 </div>
               ))}
            </div>
          </div>
        </div>

        {/* Top Selling Sidebar */}
        <div className="space-y-4">
          <div className="flex items-center justify-between relative">
            <h3 className="text-lg font-black tracking-tight uppercase tracking-wider">Top Sellers</h3>
            <button 
              onClick={() => setShowTopSellersMenu(!showTopSellersMenu)} 
              className="text-text-secondary hover:text-primary p-1.5 bg-white rounded-lg shadow-sm border border-border"
            >
              <MoreVertical className="w-4 h-4" />
            </button>
            {showTopSellersMenu && (
              <div 
                className="absolute right-0 top-10 w-48 bg-white border border-slate-100 shadow-2xl rounded-2xl z-50 overflow-hidden"
              >
                <div className="py-2">
                  <button onClick={() => { setShowTopSellersMenu(false); showToastMessage('Full Report generated'); }} className="w-full px-4 py-2 text-left text-[11px] font-black uppercase tracking-widest hover:bg-slate-50 flex items-center gap-2"><FileText className="w-4 h-4 text-primary" /> View Full Report</button>
                  <button onClick={() => { setShowTopSellersMenu(false); handleExportCSV(); }} className="w-full px-4 py-2 text-left text-[11px] font-black uppercase tracking-widest hover:bg-slate-50 flex items-center gap-2"><Download className="w-4 h-4 text-emerald-500" /> Export Item Data</button>
                  <button onClick={() => { setShowTopSellersMenu(false); showToastMessage('Stats refreshed successfully'); }} className="w-full px-4 py-2 text-left text-[11px] font-black uppercase tracking-widest hover:bg-slate-50 flex items-center gap-2"><RefreshCw className="w-4 h-4 text-blue-500" /> Refresh Stats</button>
                </div>
              </div>
            )}
          </div>
          
          <div className="card space-y-3 bg-gradient-to-br from-white to-slate-50/50 p-3.5">
            {topSellers.map((item) => (
              <div key={item.name} onClick={() => setSelectedItem(item)} className="group cursor-pointer">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-white border border-border shadow-sm flex items-center justify-center text-xl">
                      {item.icon}
                    </div>
                    <div>
                      <p className="text-xs font-bold text-text-primary group-hover:text-primary leading-tight">{item.name}</p>
                      <p className="text-[9px] text-text-secondary font-bold uppercase tracking-wider mt-0.5">{item.sales} Sales</p>
                    </div>
                  </div>
                  <p className="text-xs font-black text-text-primary">{item.price}</p>
                </div>
                <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                   <div 
                     style={{ width: `${item.sales}%` }}
                     className="h-full bg-primary rounded-full shadow-[0_0_8px_rgba(var(--color-primary),0.4)]"
                   />
                </div>
              </div>
            ))}
            <button className="w-full mt-2 btn-secondary py-2.5 font-bold uppercase tracking-widest text-[10px]">
              Explore Full Catalog
            </button>
          </div>

          {/* Quick Insights Card */}
          <div className="card bg-primary p-3.5 text-white relative overflow-hidden group shadow-xl shadow-primary/30 cursor-pointer" onClick={() => showToastMessage('Optimizing Staff Schedule...')}>
             <div className="relative z-10">
                <h4 className="text-lg font-black leading-tight">Peak hours <br/>expected at 7 PM</h4>
                <p className="text-indigo-100 text-xs mt-1.5 font-medium opacity-80">Based on historical data for Wednesdays.</p>
                <button className="mt-5 px-5 py-2 bg-white text-primary rounded-lg font-bold text-[10px] uppercase tracking-widest shadow-lg">
                   Optimize Staff
                </button>
             </div>
             <TrendingUp className="absolute -bottom-4 -right-4 w-32 h-32 text-white/10 rotate-12" />
          </div>
        </div>
      </div>

      {/* Filter Modal */}
      {showFilterModal && (
        <>
          <div 
            className="fixed inset-0 bg-slate-900/40 z-[200] backdrop-blur-sm"
            onClick={() => setShowFilterModal(false)}
          />
          <div 
            className="fixed bottom-0 sm:top-1/2 left-1/2 -translate-x-1/2 sm:-translate-y-1/2 w-full max-w-md bg-white rounded-t-[2rem] sm:rounded-[2rem] shadow-2xl z-[201] overflow-hidden"
          >
            <div className="p-5 sm:p-6 border-b border-slate-50 flex justify-between items-center bg-slate-50/50">
              <h3 className="font-black uppercase tracking-tight text-lg">Filter View</h3>
              <button onClick={() => setShowFilterModal(false)} className="p-2 hover:bg-white rounded-xl shadow-sm"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-5 sm:p-6 space-y-6">
               <div className="space-y-3">
                  <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Time Range</label>
                  <div className="flex flex-wrap gap-2">
                     {['Today', 'Week', 'Month'].map(f => (
                       <button key={f} className={cn("px-4 py-2 rounded-xl text-xs font-bold border-2 border-slate-100 hover:border-primary hover:text-primary", f === 'Today' && "bg-primary text-white border-primary hover:text-white")}>{f}</button>
                     ))}
                  </div>
               </div>
               <div className="space-y-3">
                  <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Order Types</label>
                  <div className="flex flex-wrap gap-2">
                     {['Dine-in', 'Takeaway', 'Delivery'].map(f => (
                       <button key={f} className="px-4 py-2 rounded-xl text-xs font-bold border-2 border-slate-100 hover:border-primary hover:text-primary focus:bg-primary focus:text-white focus:border-primary">{f}</button>
                     ))}
                  </div>
               </div>
               <div className="space-y-3">
                  <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Metrics</label>
                  <div className="flex flex-wrap gap-2">
                     {['Revenue', 'Orders', 'Kitchen'].map(f => (
                       <button key={f} className="px-4 py-2 rounded-xl text-xs font-bold border-2 border-slate-100 hover:border-primary hover:text-primary focus:bg-primary focus:text-white focus:border-primary">{f}</button>
                     ))}
                  </div>
               </div>
            </div>
            <div className="p-5 sm:p-6 bg-slate-50 flex gap-4">
               <button onClick={() => { setShowFilterModal(false); showToastMessage('Filters reset', 'info'); }} className="flex-1 py-3 bg-white border-2 border-slate-100 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-slate-100">Reset</button>
               <button onClick={() => { setShowFilterModal(false); showToastMessage('Filters applied successfully'); }} className="flex-1 py-3 bg-primary text-white rounded-xl font-black text-[10px] uppercase tracking-widest shadow-xl shadow-primary/30">Apply Filters</button>
            </div>
          </div>
        </>
      )}

      {selectedOrder && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 sm:p-6">
          <div 
            onClick={() => setSelectedOrder(null)} className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
          />
          <div 
            className="relative w-full sm:max-w-[520px] max-h-[90vh] sm:max-h-[85vh] bg-white shadow-2xl z-[201] flex flex-col rounded-t-[2.5rem] sm:rounded-[2.5rem] overflow-hidden self-end sm:self-center"
          >
            <div className="px-5 py-5 sm:px-6 sm:py-5 border-b border-slate-50 bg-slate-50/30 flex justify-between items-center shrink-0">
              <div>
                <h3 className="text-xl sm:text-2xl font-black tracking-tight uppercase leading-none">Order #{selectedOrder.id}</h3>
                <p className="text-text-secondary text-[9px] sm:text-[10px] font-black uppercase tracking-[0.2em] mt-1.5 sm:mt-2 opacity-60">{selectedOrder.type} • Table {selectedOrder.table}</p>
              </div>
              <button onClick={() => setSelectedOrder(null)} className="p-2 sm:p-3 hover:bg-white rounded-xl sm:rounded-2xl shadow-sm border border-transparent hover:border-slate-100 group">
                <X className="w-6 h-6 sm:w-7 sm:h-7 text-text-secondary group-hover:rotate-90" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto px-5 py-6 sm:px-6 sm:py-8 space-y-6 scrollbar-hide">
               <div className="p-5 sm:p-6 bg-slate-50 rounded-[1.5rem] sm:rounded-[2rem] flex justify-between items-center">
                  <div>
                     <p className="text-[9px] sm:text-[10px] font-black text-slate-400 uppercase tracking-widest">Total Amount</p>
                     <p className="text-xl sm:text-2xl font-black text-primary mt-1">{selectedOrder.amount}</p>
                  </div>
                  <span className={cn("px-3 py-1.5 sm:px-4 sm:py-2 rounded-lg sm:rounded-xl text-[9px] sm:text-[10px] font-black uppercase tracking-widest border", selectedOrder.status === 'Ready' ? "bg-emerald-50 text-emerald-600 border-emerald-100" : "bg-orange-50 text-orange-600 border-orange-100")}>
                     {selectedOrder.status}
                  </span>
               </div>
               <div>
                  <h4 className="text-[9px] sm:text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 sm:mb-4">Order Items</h4>
                  <div className="p-4 sm:p-5 border border-slate-100 rounded-[1.25rem] sm:rounded-[1.5rem] bg-white shadow-sm font-bold text-xs sm:text-sm text-text-primary">
                     {selectedOrder.items}
                  </div>
               </div>
               <div>
                  <h4 className="text-[9px] sm:text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 sm:mb-4">Kitchen Notes</h4>
                  <p className="text-xs sm:text-sm font-medium text-slate-500 italic p-3 sm:p-4 bg-yellow-50 rounded-xl text-yellow-800">Please make it extra spicy. No onions.</p>
               </div>
            </div>
            <div className="px-5 py-5 sm:px-6 sm:py-6 border-t border-slate-50 bg-white shrink-0 space-y-3">
               {selectedOrder.status !== 'Ready' && selectedOrder.status !== 'Delivered' && (
                 <button onClick={() => updateOrderStatus(selectedOrder.id, 'Ready')} className="w-full py-3.5 sm:py-4 bg-emerald-500 text-white rounded-xl sm:rounded-2xl font-black uppercase tracking-widest text-[9px] sm:text-[10px] shadow-xl shadow-emerald-200 flex justify-center items-center gap-2">
                   <CheckCircle2 className="w-4 h-4" /> Mark as Ready
                 </button>
               )}
               {selectedOrder.status === 'Ready' && (
                 <button onClick={() => updateOrderStatus(selectedOrder.id, 'Delivered')} className="w-full py-3.5 sm:py-4 bg-primary text-white rounded-xl sm:rounded-2xl font-black uppercase tracking-widest text-[9px] sm:text-[10px] shadow-xl shadow-primary/30 flex justify-center items-center gap-2">
                   <ShoppingBag className="w-4 h-4" /> Mark as Delivered
                 </button>
               )}
               <button onClick={() => setSelectedOrder(null)} className="w-full py-3.5 sm:py-4 bg-white border-2 border-slate-100 text-slate-400 hover:text-text-primary rounded-xl sm:rounded-2xl font-black uppercase tracking-widest text-[9px] sm:text-[10px] hover:bg-slate-50">Close Details</button>
            </div>
          </div>
        </div>
      )}

      {selectedItem && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 sm:p-6">
          <div onClick={() => setSelectedItem(null)} className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" />
          <div 
            className="relative w-full sm:max-w-[520px] max-h-[90vh] sm:max-h-[85vh] bg-white shadow-2xl z-[201] flex flex-col rounded-t-[2.5rem] sm:rounded-[2.5rem] overflow-hidden self-end sm:self-center"
          >
            <div className="px-5 py-5 sm:px-6 sm:py-5 border-b border-slate-50 bg-slate-50/30 flex justify-between items-center shrink-0">
              <div className="flex items-center gap-3 sm:gap-4">
                <div className="w-10 h-10 sm:w-12 sm:h-12 bg-white rounded-xl shadow-sm flex items-center justify-center text-xl sm:text-2xl">{selectedItem.icon}</div>
                <div>
                  <h3 className="text-lg sm:text-xl font-black tracking-tight leading-none">{selectedItem.name}</h3>
                  <p className="text-text-secondary text-[8px] sm:text-[9px] font-black uppercase tracking-[0.2em] mt-1.5 sm:mt-2 opacity-60">{selectedItem.category}</p>
                </div>
              </div>
              <button onClick={() => setSelectedItem(null)} className="p-2 sm:p-2 hover:bg-white rounded-xl shadow-sm border border-transparent hover:border-slate-100 group">
                <X className="w-5 h-5 sm:w-6 sm:h-6 text-text-secondary group-hover:rotate-90" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto px-5 py-6 sm:px-6 sm:py-8 space-y-6 scrollbar-hide">
               <div className="grid grid-cols-2 gap-3 sm:gap-4">
                  <div className="p-4 sm:p-5 bg-indigo-50 rounded-xl sm:rounded-2xl border border-indigo-100">
                     <p className="text-[8px] sm:text-[9px] font-black text-primary uppercase tracking-widest">Units Sold</p>
                     <p className="text-xl sm:text-2xl font-black text-indigo-900 mt-0.5 sm:mt-1">{selectedItem.sales}</p>
                  </div>
                  <div className="p-4 sm:p-5 bg-emerald-50 rounded-xl sm:rounded-2xl border border-emerald-100">
                     <p className="text-[8px] sm:text-[9px] font-black text-emerald-600 uppercase tracking-widest">Revenue</p>
                     <p className="text-xl sm:text-2xl font-black text-emerald-900 mt-0.5 sm:mt-1">₹{selectedItem.sales * parseInt(selectedItem.price.replace('₹',''))}</p>
                  </div>
               </div>
               <div className="p-4 sm:p-5 border border-slate-100 rounded-xl sm:rounded-2xl">
                  <p className="text-[9px] sm:text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 sm:mb-3">Stock State</p>
                  <div className="flex items-center gap-2 text-xs sm:text-sm font-bold text-emerald-600 bg-emerald-50 px-3 py-2 rounded-lg w-fit">
                     <span className="w-2 h-2 rounded-full bg-emerald-500" /> In Stock
                  </div>
               </div>
            </div>
            <div className="px-5 py-5 sm:px-6 sm:py-6 border-t border-slate-50 bg-white shrink-0">
               <button onClick={() => { setSelectedItem(null); showToastMessage('Item availability updated'); }} className="w-full py-3.5 sm:py-4 bg-primary text-white rounded-xl sm:rounded-2xl font-black uppercase tracking-widest text-[9px] sm:text-[10px] shadow-xl shadow-primary/30 flex justify-center items-center gap-2">
                 Update Inventory
               </button>
            </div>
          </div>
        </div>
      )}

      {selectedStat && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 sm:p-6">
          <div 
            onClick={() => setSelectedStat(null)}
            className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
          />
          <div 
            className="relative w-full max-w-[520px] max-h-[85vh] bg-white shadow-2xl z-[201] flex flex-col rounded-[2.5rem] overflow-hidden"
          >
            <div className="px-5 py-5 sm:px-6 sm:py-6 border-b border-slate-50 bg-slate-50/30 flex justify-between items-center shrink-0">
              <div className="flex items-center gap-3 sm:gap-5">
                <div className={cn("w-12 h-12 sm:w-16 sm:h-16 rounded-[1rem] sm:rounded-[1.5rem] flex items-center justify-center shadow-xl", selectedStat.color)}>
                  <selectedStat.icon className="w-5 h-5 sm:w-7 sm:h-7 stroke-[2.5]" />
                </div>
                <div>
                  <h3 className="text-lg sm:text-2xl font-black tracking-tight uppercase leading-none">{selectedStat.name}</h3>
                  <p className="text-text-secondary text-[9px] sm:text-[10px] font-black uppercase tracking-[0.2em] mt-1 sm:mt-2 opacity-60">Intelligence Hub • Today</p>
                </div>
              </div>
              <button 
                onClick={() => setSelectedStat(null)} 
                className="p-2 sm:p-3 hover:bg-white rounded-xl sm:rounded-2xl shadow-sm border border-transparent hover:border-slate-100 group"
              >
                <X className="w-6 h-6 sm:w-7 sm:h-7 text-text-secondary group-hover:rotate-90" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto px-6 py-8 space-y-10 scrollbar-hide">
               {/* Visual KPI Summary */}
               <div className="p-6 sm:p-10 bg-primary rounded-[2rem] sm:rounded-[3rem] text-white shadow-2xl relative overflow-hidden group shadow-primary/20">
                  <div className="relative z-10 space-y-1 sm:space-y-2">
                     <p className="text-white/40 text-[8px] sm:text-[10px] font-black uppercase tracking-[0.3em]">Current Performance</p>
                     <div className="flex items-baseline gap-2 sm:gap-3">
                        <h4 className="text-3xl sm:text-5xl font-black text-white tracking-tighter">{selectedStat.value}</h4>
                        {selectedStat.isUp !== null && (
                          <span className={cn(
                            "text-[10px] sm:text-xs font-black uppercase tracking-widest",
                            selectedStat.isUp ? "text-emerald-500" : "text-rose-500"
                          )}>
                             {selectedStat.isUp ? '+' : ''}{selectedStat.change}
                          </span>
                        )}
                     </div>
                  </div>
                  <selectedStat.icon className="absolute -bottom-6 -right-6 sm:-bottom-10 sm:-right-10 w-24 h-24 sm:w-44 sm:h-44 text-white opacity-[0.05] -rotate-12" />
               </div>

               <div className="space-y-6">
                  <div className="flex items-center justify-between px-2">
                     <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.25em]">Velocity Analysis</h4>
                     <span className="text-[9px] font-black text-primary px-3 py-1 bg-indigo-50 rounded-full tracking-widest uppercase">Live Pulse</span>
                  </div>
                  <div className="space-y-4">
                     {[1,2,3,4].map(i => (
                        <div 
                          key={i} 
                          className="flex items-center justify-between p-4 sm:p-5 bg-slate-50/50 hover:bg-slate-50 rounded-[1.5rem] sm:rounded-[2rem] border border-transparent hover:border-slate-100 shadow-sm group cursor-pointer"
                        >
                           <div className="flex items-center gap-3 sm:gap-5">
                              <div className="w-10 h-10 sm:w-12 sm:h-12 bg-white rounded-xl sm:rounded-2xl flex items-center justify-center font-black text-[8px] sm:text-[10px] border border-slate-50 group-hover:border-primary/20 text-slate-400">
                                 {12+i}:00
                              </div>
                              <div>
                                 <p className="font-black text-xs sm:text-sm text-text-primary uppercase tracking-tight">Shift Sequence</p>
                                 <p className="text-[9px] sm:text-[10px] font-bold text-slate-400 mt-0.5 uppercase tracking-widest">Efficiency: 94%</p>
                              </div>
                           </div>
                           <div className="text-right">
                              <p className="font-black text-text-primary text-base sm:text-lg tracking-tighter">
                                {selectedStat.id === 'revenue' ? `₹${(5-i)*2400}` : selectedStat.id === 'orders' ? `${(5-i)*12}` : selectedStat.id === 'tables' ? `${i*2}` : `${i*5}m`}
                              </p>
                              <ChevronRight className="w-3.5 h-3.5 text-slate-200 float-right mt-1" />
                           </div>
                        </div>
                     ))}
                  </div>
               </div>
            </div>

            <div className="p-5 sm:p-6 border-t border-slate-50 grid grid-cols-2 gap-3 sm:gap-4 bg-white shrink-0">
               <button onClick={() => { setSelectedStat(null); showToastMessage('Audit Printed Successfully'); }} className="py-3 sm:py-4.5 border-2 border-slate-100 rounded-xl sm:rounded-2xl font-black uppercase tracking-widest text-[9px] sm:text-[10px] hover:bg-slate-50 shadow-sm">Print Audit</button>
               <button onClick={() => { setSelectedStat(null); showToastMessage('Exported to Intelligence Center'); }} className="btn-primary py-3 sm:py-4.5 rounded-xl sm:rounded-2xl font-black uppercase tracking-widest text-[9px] sm:text-[10px] shadow-2xl shadow-primary/30">Intelligence Center</button>
            </div>
          </div>
        </div>
      )}

      {/* Add Item Modal */}
      {showAddItemModal && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
          <div onClick={() => setShowAddItemModal(false)} className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" />
          <div 
            className="relative w-full max-w-[520px] bg-white rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
          >
            <div className="px-6 py-5 sm:px-8 sm:py-6 border-b border-slate-50 flex justify-between items-center bg-slate-50/30">
              <div>
                <h3 className="text-xl sm:text-2xl font-black tracking-tight uppercase">New Menu Item</h3>
                <p className="text-[9px] sm:text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">POS Inventory Creation</p>
              </div>
              <button onClick={() => setShowAddItemModal(false)} className="p-2 sm:p-3 hover:bg-white rounded-xl sm:rounded-2xl shadow-sm group">
                <X className="w-6 h-6 text-text-secondary group-hover:rotate-90" />
              </button>
            </div>
            
            <form 
              className="p-6 sm:p-8 space-y-5 sm:space-y-6 overflow-y-auto scrollbar-hide"
              onSubmit={(e) => {
                e.preventDefault();
                const formData = new FormData(e.target);
                const name = formData.get('name');
                const category = newItemCategory;
                const price = parseFloat(formData.get('price'));
                const image = newItemIcon;
                const description = formData.get('description');
                
                if (!name || !category || isNaN(price) || price <= 0) {
                  showToastMessage('Please fill all required fields correctly', 'error');
                  return;
                }
                
                handleAddItem({ name, category, price, image, description });
              }}
            >
              <div className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-[9px] sm:text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Item Name *</label>
                    <input name="name" type="text" placeholder="e.g. Garlic Bread" className="w-full px-4 sm:px-5 py-3 sm:py-3.5 bg-slate-50 border-2 border-transparent focus:border-primary/20 focus:bg-white rounded-xl sm:rounded-2xl outline-none font-bold text-xs sm:text-sm" required />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[9px] sm:text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Category *</label>
                    <input 
                      name="category" 
                      type="text" 
                      list="categories" 
                      value={newItemCategory}
                      onChange={(e) => {
                        setNewItemCategory(e.target.value);
                        updateAutoIcon(e.target.value);
                      }}
                      placeholder="e.g. Sides" 
                      className="w-full px-4 sm:px-5 py-3 sm:py-3.5 bg-slate-50 border-2 border-transparent focus:border-primary/20 focus:bg-white rounded-xl sm:rounded-2xl outline-none font-bold text-xs sm:text-sm" 
                      required 
                    />
                    <datalist id="categories">
                      {categoriesList.filter(c => c !== 'All').map(c => <option key={c} value={c} />)}
                    </datalist>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-[9px] sm:text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Price (₹) *</label>
                    <input name="price" type="number" step="0.01" placeholder="99.00" className="w-full px-4 sm:px-5 py-3 sm:py-3.5 bg-slate-50 border-2 border-transparent focus:border-primary/20 focus:bg-white rounded-xl sm:rounded-2xl outline-none font-bold text-xs sm:text-sm" required />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[9px] sm:text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Emoji / Icon</label>
                    <input 
                      name="image" 
                      type="text" 
                      value={newItemIcon}
                      onChange={(e) => setNewItemIcon(e.target.value)}
                      placeholder="🍟" 
                      className="w-full px-4 sm:px-5 py-3 sm:py-3.5 bg-slate-50 border-2 border-transparent focus:border-primary/20 focus:bg-white rounded-xl sm:rounded-2xl outline-none font-bold text-xs sm:text-sm" 
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[9px] sm:text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Description</label>
                  <textarea name="description" placeholder="Short description..." className="w-full px-4 sm:px-5 py-3 sm:py-4 bg-slate-50 border-2 border-transparent focus:border-primary/20 focus:bg-white rounded-xl sm:rounded-2xl outline-none font-bold text-xs sm:text-sm min-h-[80px] sm:min-h-[100px] resize-none" />
                </div>
              </div>

              <div className="pt-2 sm:pt-4 flex gap-3 sm:gap-4">
                <button type="button" onClick={() => setShowAddItemModal(false)} className="flex-1 py-3.5 sm:py-4 bg-slate-50 text-slate-500 rounded-xl sm:rounded-2xl font-black uppercase tracking-widest text-[9px] sm:text-[10px] hover:bg-slate-100">Cancel</button>
                <button type="submit" className="flex-1 py-3.5 sm:py-4 bg-primary text-white rounded-xl sm:rounded-2xl font-black uppercase tracking-widest text-[9px] sm:text-[10px] shadow-xl shadow-primary/30">Create Item</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
