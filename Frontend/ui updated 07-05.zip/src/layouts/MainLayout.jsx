import React, { useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Table2, 
  Calculator, 
  ClipboardList, 
  CookingPot, 
  UtensilsCrossed, 
  Users, 
  BarChart3, 
  Settings, 
  LogOut,
  Bell,
  Search,
  User as UserIcon,
  ChevronLeft,
  ChevronRight,
  Menu as MenuIcon,
  Home,
  ShoppingCart,
  History,
  Heart,
  Gift,
  HelpCircle,
  Smartphone
} from 'lucide-react';
import { useAuth, roles } from '../context/AuthContext';
import { cn } from '../utils/cn';

const MainLayout = ({ children }) => {
  const { user, login, logout } = useAuth();
  const navigate = useNavigate();
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchFocused, setIsSearchFocused] = useState(false);

  const menuItems = [
    { name: 'Dashboard', icon: LayoutDashboard, path: '/', roles: [roles.ADMIN, roles.MANAGER] },
    { name: 'Tables', icon: Table2, path: '/tables', roles: [roles.ADMIN, roles.MANAGER, roles.WAITER] },
    { name: 'POS', icon: Calculator, path: '/pos', roles: [roles.ADMIN, roles.MANAGER, roles.WAITER, roles.CASHIER] },
    { name: 'Orders', icon: ClipboardList, path: '/orders', roles: [roles.ADMIN, roles.MANAGER, roles.WAITER, roles.CHEF, roles.CASHIER] },
    { name: 'Kitchen', icon: CookingPot, path: '/kitchen', roles: [roles.ADMIN, roles.MANAGER, roles.CHEF] },
    { name: 'Menu', icon: UtensilsCrossed, path: '/menu', roles: [roles.ADMIN, roles.MANAGER] },
    { name: 'Staff', icon: Users, path: '/staff', roles: [roles.ADMIN] },
    { name: 'Reports', icon: BarChart3, path: '/reports', roles: [roles.ADMIN, roles.MANAGER] },
    { name: 'Settings', icon: Settings, path: '/settings', roles: [roles.ADMIN] },
    
    // Customer Specific Items
    { name: 'Home', icon: Home, path: '/customer', roles: [roles.CUSTOMER] },
    { name: 'Order Now', icon: UtensilsCrossed, path: '/customer/order', roles: [roles.CUSTOMER] },
    { name: 'Orders', icon: History, path: '/customer/orders', roles: [roles.CUSTOMER] },
    { name: 'Favorites', icon: Heart, path: '/customer/favorites', roles: [roles.CUSTOMER] },
    { name: 'Rewards', icon: Gift, path: '/customer/rewards', roles: [roles.CUSTOMER] },
    { name: 'Profile', icon: UserIcon, path: '/customer/profile', roles: [roles.CUSTOMER] },
    { name: 'Support', icon: HelpCircle, path: '/customer/support', roles: [roles.CUSTOMER] },
  ];

  const filteredMenu = menuItems.filter(item => item.roles.includes(user?.role));

  return (
    <div className="fixed inset-0 flex bg-background overflow-hidden font-['Inter']">
      {/* Sidebar */}
      <aside 
        className={cn(
          "bg-white border-r border-border flex flex-col relative z-[100] shadow-[4px_0_24px_rgba(0,0,0,0.02)] h-full transition-all duration-300",
          "lg:translate-x-0 fixed lg:relative",
          isCollapsed ? "lg:w-[80px]" : "lg:w-[200px]",
          isMobileMenuOpen ? "translate-x-0 w-[240px]" : "-translate-x-full lg:translate-x-0"
        )}
      >
        {/* Logo Area */}
        <div className="h-14 flex items-center px-5 shrink-0">
          <div className="flex items-center gap-2.5 overflow-hidden">
            <div className="w-8 h-8 bg-primary rounded-xl flex items-center justify-center text-white shadow-lg shadow-primary/30 shrink-0">
              <CookingPot className="w-5 h-5 stroke-[2.5]" />
            </div>
            {!isCollapsed && (
              <span 
                className="text-lg font-black tracking-tight text-text-primary whitespace-nowrap"
              >
                Resto<span className="text-primary">OS</span>
              </span>
            )}
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-2.5 py-3 space-y-0.5 overflow-y-auto scrollbar-hide">
          {filteredMenu.map((item) => (
            <NavLink
              key={item.name}
              to={item.path}
              end={item.path === '/' || item.path === '/customer'}
              onClick={() => setIsMobileMenuOpen(false)}
              className={({ isActive }) => cn(
                "group relative flex items-center gap-3 px-3 py-2.5 rounded-xl",
                isActive 
                  ? "bg-primary text-white shadow-xl shadow-primary/20" 
                  : "text-text-secondary hover:bg-slate-50 hover:text-text-primary"
              )}
            >
              <item.icon className={cn("w-5 h-5 shrink-0", !isCollapsed && "stroke-[2]")} />
              {!isCollapsed && (
                <span 
                  className="font-bold text-xs tracking-wide"
                >
                  {item.name}
                </span>
              )}
              {isCollapsed && (
                <div className="absolute left-full ml-4 px-2 py-1.5 bg-text-primary text-white text-[9px] font-black uppercase tracking-widest rounded-lg opacity-0 group-hover:opacity-100 pointer-events-none z-[100]">
                  {item.name}
                </div>
              )}
            </NavLink>
          ))}
        </nav>

        {/* Sidebar Footer */}
        <div className="p-2.5 space-y-0.5 border-t border-slate-50">

          <button 
            onClick={() => { logout(); navigate('/login'); }}
            className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-text-secondary hover:bg-danger/5 hover:text-danger group"
          >
            <LogOut className="w-5 h-5 shrink-0" />
            {!isCollapsed && <span className="font-bold text-xs">Logout</span>}
          </button>
        </div>

        {/* Toggle Button (Hidden on Mobile) */}
        <button 
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="absolute -right-4 top-10 w-8 h-8 bg-white border border-border rounded-full hidden lg:flex items-center justify-center text-text-secondary hover:text-primary shadow-xl z-30"
        >
          {isCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
        </button>
      </aside>

      {/* Mobile Overlay */}
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-[90] lg:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col overflow-hidden relative bg-background">
        {/* Premium SaaS Background Blobs */}
        <div className="absolute top-[-10%] right-[-5%] w-[40rem] h-[40rem] bg-primary/[0.03] rounded-full blur-[100px] pointer-events-none" />
        <div className="absolute bottom-[-10%] left-[-5%] w-[35rem] h-[35rem] bg-indigo-400/[0.03] rounded-full blur-[100px] pointer-events-none" />
        <div className="absolute top-[20%] left-[10%] w-[30rem] h-[30rem] bg-blue-300/[0.02] rounded-full blur-[80px] pointer-events-none" />
                {/* Header */}
        <header className="h-14 bg-white border-b border-border flex items-center justify-between px-3 lg:px-4 shrink-0 z-20">
          <div className="flex items-center gap-3 lg:gap-6 flex-1">
            <button 
              onClick={() => setIsMobileMenuOpen(true)}
              className="lg:hidden p-2 text-text-secondary hover:text-primary"
            >
              <MenuIcon className="w-6 h-6" />
            </button>
            <div 
              className="relative w-full max-w-[420px] group z-[100]"
            >
              <div
                className={cn(
                  "absolute left-4 top-1/2 -translate-y-1/2 z-20 pointer-events-none",
                  isSearchFocused ? "text-primary" : "text-text-secondary"
                )}
              >
                <Search className="w-4 h-4" />
              </div>
              <input 
                type="text" 
                value={searchQuery}
                onFocus={() => setIsSearchFocused(true)}
                onBlur={() => setIsSearchFocused(false)}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search..." 
                className={cn(
                  "w-full pl-10 pr-4 py-2 bg-slate-50 lg:bg-white border-2 rounded-xl lg:rounded-2xl outline-none text-xs font-bold relative z-10 transition-all",
                  isSearchFocused 
                    ? "border-primary ring-4 ring-primary/10 shadow-lg shadow-primary/5" 
                    : "border-primary/20"
                )}
              />
              
              {searchQuery.length > 0 && (
                <>
                  <div className="fixed inset-0 z-0" onClick={() => setSearchQuery('')} />
                  <div 
                    className="absolute top-full mt-3 w-full bg-white border border-slate-100 rounded-3xl shadow-2xl overflow-hidden z-10 p-2"
                  >
                    <div className="p-2">
                      <div className="px-3 py-2">
                        <p className="text-[9px] font-black uppercase tracking-widest text-slate-400 mb-2">Orders</p>
                        <button onClick={() => { setSearchQuery(''); navigate('/orders'); }} className="w-full text-left px-3 py-2 hover:bg-slate-50 rounded-xl text-xs font-bold flex justify-between items-center group">
                           Order #124 <ChevronRight className="w-3 h-3 text-slate-300 group-hover:text-primary" />
                        </button>
                      </div>
                      <div className="px-3 py-2 border-t border-slate-50">
                        <p className="text-[9px] font-black uppercase tracking-widest text-slate-400 mb-2">Tables</p>
                        <button onClick={() => { setSearchQuery(''); navigate('/tables'); }} className="w-full text-left px-3 py-2 hover:bg-slate-50 rounded-xl text-xs font-bold flex justify-between items-center group">
                           Table T-03 <ChevronRight className="w-3 h-3 text-slate-300 group-hover:text-primary" />
                        </button>
                      </div>
                      <div className="px-3 py-2 border-t border-slate-50">
                        <p className="text-[9px] font-black uppercase tracking-widest text-slate-400 mb-2">Menu</p>
                        <button onClick={() => { setSearchQuery(''); navigate('/menu'); }} className="w-full text-left px-3 py-2 hover:bg-slate-50 rounded-xl text-xs font-bold flex justify-between items-center group">
                           Margherita Pizza <ChevronRight className="w-3 h-3 text-slate-300 group-hover:text-primary" />
                        </button>
                      </div>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>

          <div className="flex items-center gap-4">
            <button 
              className="relative p-2 bg-slate-50 rounded-xl text-text-secondary hover:text-primary"
            >
              <Bell className="w-5 h-5" />
              <span className="absolute top-2.5 right-2.5 w-2 h-2 bg-danger rounded-full border-2 border-white shadow-sm"></span>
            </button>
            
            <div className="h-8 w-[1px] bg-border mx-1"></div>

            <div className="flex items-center gap-3">
              <div className="text-right hidden sm:block">
                <p className="text-xs font-black text-text-primary leading-none">{user?.name}</p>
                <div className="mt-1 flex justify-end">
                   <span className="badge bg-primary-light text-primary border-none text-[8px] py-0 font-bold uppercase tracking-wider">
                      {user?.role}
                   </span>
                </div>
              </div>
              <div 
                className="w-10 h-10 bg-slate-100 rounded-xl flex items-center justify-center text-primary border-2 border-white shadow-lg cursor-pointer overflow-hidden"
              >
                <UserIcon className="w-5 h-5 stroke-[2.5]" />
              </div>
            </div>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 overflow-y-auto px-4 lg:px-6 pt-4 lg:pt-6 pb-20 lg:pb-8 bg-transparent relative scrollbar-hide">
          <div className="max-w-[1600px] mx-auto">
            {children}
          </div>
        </main>
      </div>

      {/* Mobile Bottom Navigation (Only for Customers) */}
      {user?.role === roles.CUSTOMER && (
        <div className="lg:hidden fixed bottom-0 left-0 right-0 h-16 bg-white/80 backdrop-blur-xl border-t border-border z-[100] px-4 flex items-center justify-between shadow-[0_-10px_25px_rgba(0,0,0,0.05)]">
           {[
    { name: 'Home', icon: Home, path: '/customer' },
    { name: 'Order Now', icon: UtensilsCrossed, path: '/customer/order' },
    { name: 'Orders', icon: History, path: '/customer/orders' },
    { name: 'Profile', icon: UserIcon, path: '/customer/profile' },
  ].map(item => (
             <NavLink 
               key={item.name} 
               to={item.path}
               end={item.path === '/customer'}
               className={({ isActive }) => cn(
                 "flex flex-col items-center gap-1 transition-all",
                 isActive ? "text-primary scale-110" : "text-slate-400"
               )}
             >
                <item.icon className="w-5 h-5 stroke-[2.5]" />
                <span className="text-[8px] font-black uppercase tracking-widest">{item.name}</span>
             </NavLink>
           ))}
        </div>
      )}
    </div>
  );
};

export default MainLayout;
