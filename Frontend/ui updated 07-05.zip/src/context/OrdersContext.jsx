import React, { createContext, useContext, useState, useEffect } from 'react';

const OrdersContext = createContext();

export const useOrders = () => useContext(OrdersContext);

export const OrdersProvider = ({ children }) => {
  const [orders, setOrders] = useState(() => {
    const savedOrders = localStorage.getItem('resto-orders');
    return savedOrders ? JSON.parse(savedOrders) : [
      { id: '#1024', type: 'Dine-in', table: 'T-05', status: 'Ready', amount: '₹450', time: '12:45 PM', items: 3, date: 'Today', customer: 'Rahul K.', payment: 'UPI', itemsList: [{ name: 'Margherita Pizza', quantity: 2, price: 399 }, { name: 'Coke', quantity: 1, price: 49 }], timestamp: new Date(Date.now() - 3600000).toISOString() },
      { id: '#1025', type: 'Takeaway', table: '-', status: 'Cooking', amount: '₹120', time: '1:10 PM', items: 1, date: 'Today', customer: 'Guest', payment: 'Cash', itemsList: [{ name: 'Cheese Burger', quantity: 1, price: 120 }], timestamp: new Date(Date.now() - 1800000).toISOString() },
      { id: '#1026', type: 'Dine-in', table: 'T-02', status: 'Pending', amount: '₹890', time: '1:15 PM', items: 5, date: 'Today', customer: 'Priya S.', payment: 'Card', itemsList: [{ name: 'Pasta', quantity: 2, price: 445 }], timestamp: new Date(Date.now() - 900000).toISOString() },
    ];
  });

  useEffect(() => {
    localStorage.setItem('resto-orders', JSON.stringify(orders));
  }, [orders]);

  const addOrder = (newOrder) => {
    const orderWithId = {
      ...newOrder,
      id: `#${Math.floor(1000 + Math.random() * 9000)}`,
      date: 'Today',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      timestamp: new Date().toISOString()
    };
    setOrders(prev => [orderWithId, ...prev]);
    return orderWithId;
  };

  const updateOrderStatus = (orderId, status) => {
    setOrders(prev => prev.map(order => 
      order.id === orderId ? { ...order, status } : order
    ));
  };

  const updatePaymentStatus = (orderId, paymentStatus) => {
    setOrders(prev => prev.map(order => 
      order.id === orderId ? { ...order, paymentStatus } : order
    ));
  };

  const cancelOrder = (orderId) => {
    setOrders(prev => prev.map(order => 
      order.id === orderId ? { ...order, status: 'Cancelled' } : order
    ));
  };

  return (
    <OrdersContext.Provider value={{ orders, addOrder, updateOrderStatus, updatePaymentStatus, cancelOrder }}>
      {children}
    </OrdersContext.Provider>
  );
};
