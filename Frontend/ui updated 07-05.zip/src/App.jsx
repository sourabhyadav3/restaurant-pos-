import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth, roles } from './context/AuthContext';
import { MenuProvider } from './context/MenuContext';
import { OrdersProvider } from './context/OrdersContext';
import { CustomerProvider } from './context/CustomerContext';
import MainLayout from './layouts/MainLayout';
import Dashboard from './pages/Dashboard';
import Tables from './pages/Tables';
import POS from './pages/POS';
import Orders from './pages/Orders';
import Kitchen from './pages/Kitchen';
import Menu from './pages/Menu';
import Staff from './pages/Staff';
import Reports from './pages/Reports';
import Settings from './pages/Settings';
import Login from './pages/Login';
import CustomerHome from './pages/CustomerHome';
import CustomerOrderNow from './pages/CustomerOrderNow';
import CustomerOrders from './pages/CustomerOrders';
import CustomerFavorites from './pages/CustomerFavorites';
import CustomerRewards from './pages/CustomerRewards';
import CustomerProfile from './pages/CustomerProfile';
import CustomerSupport from './pages/CustomerSupport';

const ProtectedRoute = ({ children, allowedRoles }) => {
  const { user } = useAuth();
  
  if (!user) return <Navigate to="/login" />;
  if (allowedRoles && !allowedRoles.includes(user.role)) {
    // Redirect based on role instead of always to /
    if (user.role === roles.CUSTOMER) return <Navigate to="/customer" />;
    if (user.role === roles.WAITER) return <Navigate to="/tables" />;
    if (user.role === roles.CHEF) return <Navigate to="/kitchen" />;
    if (user.role === roles.CASHIER) return <Navigate to="/pos" />;
    return <Navigate to="/" />; 
  }
  
  return <MainLayout>{children}</MainLayout>;
};

const ThemeHandler = () => {
  React.useEffect(() => {
    const savedTheme = localStorage.getItem('pos-theme') || 'indigo';
    const themes = {
      indigo: { primary: '#6366F1', dark: '#4F46E5', light: '#EEF2FF' },
      rose: { primary: '#F43F5E', dark: '#E11D48', light: '#FFF1F2' },
      emerald: { primary: '#10B981', dark: '#059669', light: '#ECFDF5' },
      orange: { primary: '#F59E0B', dark: '#D97706', light: '#FFFBEB' },
      purple: { primary: '#9333EA', dark: '#7E22CE', light: '#FAF5FF' }
    };

    const theme = themes[savedTheme];
    if (theme) {
      document.documentElement.style.setProperty('--color-primary', theme.primary);
      document.documentElement.style.setProperty('--color-primary-dark', theme.dark);
      document.documentElement.style.setProperty('--color-primary-light', theme.light);
    }
  }, []);
  return null;
};

const DashboardSelector = () => {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" />;
  
  switch(user.role) {
    case roles.ADMIN:
    case roles.MANAGER: return <Dashboard />;
    case roles.WAITER: return <Navigate to="/tables" />;
    case roles.CHEF: return <Navigate to="/kitchen" />;
    case roles.CASHIER: return <Navigate to="/pos" />;
    case roles.CUSTOMER: return <Navigate to="/customer" />;
    default: return <Navigate to="/login" />;
  }
};

function App() {
  return (
    <MenuProvider>
      <OrdersProvider>
        <CustomerProvider>
          <AuthProvider>
            <ThemeHandler />
            <Router>
          <Routes>
            <Route path="/login" element={<Login />} />
            
            <Route path="/" element={
              <MainLayout>
                <DashboardSelector />
              </MainLayout>
            } />
            
            <Route path="/tables" element={
              <ProtectedRoute allowedRoles={[roles.ADMIN, roles.MANAGER, roles.WAITER]}>
                <Tables />
              </ProtectedRoute>
            } />
            
            <Route path="/pos" element={
              <ProtectedRoute allowedRoles={[roles.ADMIN, roles.MANAGER, roles.WAITER, roles.CASHIER]}>
                <POS />
              </ProtectedRoute>
            } />
            
            <Route path="/orders" element={
              <ProtectedRoute allowedRoles={[roles.ADMIN, roles.MANAGER, roles.WAITER, roles.CHEF, roles.CASHIER]}>
                <Orders />
              </ProtectedRoute>
            } />
            
            <Route path="/kitchen" element={
              <ProtectedRoute allowedRoles={[roles.ADMIN, roles.MANAGER, roles.CHEF]}>
                <Kitchen />
              </ProtectedRoute>
            } />
            
            <Route path="/menu" element={
              <ProtectedRoute allowedRoles={[roles.ADMIN, roles.MANAGER]}>
                <Menu />
              </ProtectedRoute>
            } />
            
            <Route path="/staff" element={
              <ProtectedRoute allowedRoles={[roles.ADMIN]}>
                <Staff />
              </ProtectedRoute>
            } />
            
            <Route path="/reports" element={
              <ProtectedRoute allowedRoles={[roles.ADMIN, roles.MANAGER]}>
                <Reports />
              </ProtectedRoute>
            } />
            
            <Route path="/settings" element={
              <ProtectedRoute allowedRoles={[roles.ADMIN]}>
                <Settings />
              </ProtectedRoute>
            } />

            {/* Customer Routes */}
            <Route path="/customer" element={
              <ProtectedRoute allowedRoles={[roles.CUSTOMER]}>
                <CustomerHome />
              </ProtectedRoute>
            } />
            <Route path="/customer/order" element={
              <ProtectedRoute allowedRoles={[roles.CUSTOMER]}>
                <CustomerOrderNow />
              </ProtectedRoute>
            } />
            <Route path="/customer/orders" element={
              <ProtectedRoute allowedRoles={[roles.CUSTOMER]}>
                <CustomerOrders />
              </ProtectedRoute>
            } />
            <Route path="/customer/favorites" element={
              <ProtectedRoute allowedRoles={[roles.CUSTOMER]}>
                <CustomerFavorites />
              </ProtectedRoute>
            } />
            <Route path="/customer/rewards" element={
              <ProtectedRoute allowedRoles={[roles.CUSTOMER]}>
                <CustomerRewards />
              </ProtectedRoute>
            } />
            <Route path="/customer/profile" element={
              <ProtectedRoute allowedRoles={[roles.CUSTOMER]}>
                <CustomerProfile />
              </ProtectedRoute>
            } />
            <Route path="/customer/support" element={
              <ProtectedRoute allowedRoles={[roles.CUSTOMER]}>
                <CustomerSupport />
              </ProtectedRoute>
            } />
            
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </Router>
      </AuthProvider>
    </CustomerProvider>
  </OrdersProvider>
</MenuProvider>
  );
}

export default App;
